# File manifest

```
Offline-Learning-Website-Builder/
├── README.md, INSTALL.md, USER_GUIDE.md, TESTING_REPORT.md, FILE_MANIFEST.md
├── ready-to-install/offline-learning-website-builder/   <- copy THIS folder into .obsidian/plugins/
│   ├── main.js          compiled plugin (bundles PDF.js + KaTeX + runtime)
│   ├── manifest.json
│   └── styles.css
└── source/
    ├── manifest.json, versions.json, package.json, tsconfig.json, esbuild.config.mjs, styles.css
    ├── scripts/        prepare-vendor.mjs (bundles PDF.js/KaTeX), run-tests.mjs
    ├── tests/          make-fixture.cjs, export-fixture.ts, browser-test.cjs, obsidian-smoke.cjs,
    │                   unit-security.ts, obsidian-glue.ts, node-shim.d.ts, obsidian-stub.d.ts
    └── src/
        ├── main.ts                      plugin entry
        ├── globals.d.ts                 "*.txt" module declaration
        ├── obsidian/                    Obsidian-facing code
        │   ├── main.ts        ribbon, 7 commands, context menus, settings load/save
        │   ├── settings.ts    settings tab + beginner help
        │   ├── wizard.ts      7-step wizard, course manager, designer, live preview
        │   ├── modals.ts      folder/note/image pickers, export panel, quick export dialog
        │   ├── exporter.ts    plan/export/preview glue
        │   ├── adapter.ts     Obsidian vault -> VaultAdapter
        │   └── system.ts      folder picker, open path/folder (Electron), temp dir
        ├── core/                        Obsidian-free exporter (unit/e2e testable in Node)
        │   ├── types.ts, util.ts, frontmatter.ts, icons.ts
        │   ├── markdown.ts    Obsidian Markdown -> sanitised HTML
        │   ├── builder.ts     planSite() / writePlan()
        │   ├── layout.ts      HTML templates (home, course, nav, README)
        │   ├── design.ts      presets, fonts, design variables
        │   ├── preview.ts     in-Obsidian homepage preview
        │   ├── nodeio.ts      safe folder writer, folder-as-vault adapter (tests)
        │   └── vendor.ts      embeds the text assets below
        ├── runtime/           code that runs inside exported websites
        │   ├── site.css.txt, runtime.js.txt, pdf-viewer.js.txt
        └── vendor/            pdfjs-lib.js.txt, pdf-worker.mjs.txt, katex.min.js.txt, katex.css.txt
```
