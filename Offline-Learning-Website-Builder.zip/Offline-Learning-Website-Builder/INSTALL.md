# Installation guide (for beginners)

You do **not** need to write or compile any code. The folder `ready-to-install/offline-learning-website-builder` already contains the finished plugin (three files: `main.js`, `manifest.json`, `styles.css`).

## Requirements
- Obsidian **desktop** (Windows, macOS or Linux), version 1.4.0 or newer. The plugin is desktop-only because it writes files to your computer.
- A modern browser (Chrome, Edge, Firefox, Safari) to open the exported website.

## Steps
1. Unzip `Offline-Learning-Website-Builder.zip` anywhere.
2. Find your vault folder on disk. (In Obsidian: click the vault name at the bottom-left → "Manage vaults" → the path is shown; or use "Reveal vault in system file explorer".)
3. Inside the vault there is a hidden folder called `.obsidian`. If you can't see it:
   - Windows: File Explorer → View → Show → **Hidden items**.
   - macOS: in Finder press **Cmd + Shift + .**
   - Linux: press **Ctrl + H** in the file manager.
4. Open `.obsidian`. If there is no `plugins` folder, create one.
5. Copy the whole folder `offline-learning-website-builder` (from `ready-to-install`) into `.obsidian/plugins/`.  
   You should end up with: `.obsidian/plugins/offline-learning-website-builder/main.js` (plus `manifest.json` and `styles.css`).
6. In Obsidian: **Settings → Community plugins**.
   - If "Restricted mode" is on, click **Turn on community plugins** and confirm.
   - Click the **reload** icon next to "Installed plugins" (or restart Obsidian).
7. Switch on **Offline Learning Website Builder**.
8. A graduation-cap icon appears in the left ribbon. Click it to start.

## Updating or removing
- Update: replace the three files with a newer version and reload Obsidian.
- Remove: switch the plugin off, then delete its folder. Websites you already exported are plain files and keep working.

## Building from source (optional, for developers)
```
cd source
npm install
npm run build        # type-checks, then writes main.js
npm test             # end-to-end tests (needs ffmpeg + optional deps pdf-lib, sharp, playwright)
npm run vendor       # rebuilds the bundled PDF.js / KaTeX copies in src/vendor
```
The PDF.js and KaTeX files needed at runtime are already committed in `source/src/vendor`, so `npm run build` needs no internet other than `npm install`.
