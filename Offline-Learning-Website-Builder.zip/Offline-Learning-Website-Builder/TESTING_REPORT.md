# Testing report

Honest status of every feature: **Tested** = verified by an automated test run in this build environment; **Implemented, not tested** = code exists but could not be exercised here.

## Environment used
Linux sandbox, Node + esbuild + TypeScript, Playwright **Chromium** (headless) opening exported pages through `file://` URLs, ffmpeg-generated WAV and WebM files, a pdf-lib generated 3-page PDF, a PNG made with sharp. No internet was available (which doubled as an offline check: zero http(s) requests were made).

## Results
| Suite | Result |
|---|---|
| Browser end-to-end (`tests/browser-test.cjs`) | **81 / 81 passed** |
| Obsidian glue with mocked `obsidian` module (`tests/obsidian-smoke.cjs`, loads the real built `main.js`) | **13 / 13 passed** |
| Security unit tests (`tests/unit-security.ts`) | **8 / 8 passed** |
| TypeScript type-check | passes **against a hand-written stub** of the `obsidian` typings (see limits) |

## Feature matrix
| Area | Status |
|---|---|
| Mode B: homepage + course pages + assets, relative links, `README.html` | **Tested** (file://) |
| Mode A: single HTML with everything embedded; single HTML + assets folder | **Tested** |
| Bundled PDF.js viewer: render, prev/next, page box, zoom, fit width/page, search + highlight, `#page=N`, multiple PDFs, download (site and embedded), fullscreen, error panel | **Tested** (error panel code path: implemented, only the success paths were exercised) |
| Audio player (play, seek control, volume, speed, time, download) – WAV | **Tested** |
| Video player (play, speed, volume, fullscreen button, download) – WebM | **Tested**. MP4/H.264: **not tested** (the sandbox Chromium has no proprietary codecs) |
| Homepage: hero, search, categories filter, cards, featured, favourites, recently opened (“Continue learning”), progress | **Tested** |
| Light / dark / system theme, persistence, fallback when storage unavailable | **Tested** in Chromium (localStorage path). The `window.name` fallback is implemented, not separately tested |
| Navigation: Home, Courses menu, previous/next course, breadcrumbs, search, theme switch, cross-course links | **Tested** |
| Markdown: headings, emphasis, lists, tasks, tables, quotes, code, callouts (+foldable), wikilinks, aliases, heading links, images + sizes, embeds, note transclusion (heading/block), tags, comments, math (bundled KaTeX), Unicode (Bengali) | **Tested** on a fixture vault |
| Security: raw `<script>`, `onerror`, `javascript:` links neutralised; path traversal (`../`) in links/embeds never exports files; output writer rejects `..`, absolute paths and drive roots; unlinked vault files are not exported | **Tested** |
| Search (Ctrl+K, snippets, cross-course navigation), in single-file mode too | **Tested** |
| Bookmarks, recents, library drawer, mark complete, sidebar/home progress, focus mode, print stylesheet, TOC | **Tested** |
| Responsive layout (390 px viewport): no horizontal overflow, lesson drawer | **Tested** (emulated viewport, not a real phone) |
| Update Existing Website: stale generated files removed, user files kept | **Tested** (through the adapter glue) |
| Large-file handling: size estimate, warnings, refusal to embed files > 300 MB | Implemented; thresholds **not tested with real large files** |
| Plugin: ribbon icon, 7 commands, context-menu registration | **Tested against the mock** only |
| Wizard (7 steps), course manager, visual designer, live preview, quick-export dialog, settings tab | **Implemented, NOT tested in real Obsidian.** The live-preview HTML it uses *was* rendered and checked in Chromium for all 4 presets |
| Folder picker (“Browse…”), “open folder/file” and “Preview in browser” | **Implemented, NOT tested.** They rely on Electron APIs available inside Obsidian; typing the folder path always works |

## Known limits and caveats (please read)
1. **Never run inside real Obsidian here.** The `obsidian` npm package could not be installed offline. I used only documented APIs (`Plugin`, `Modal`, `Setting`, `FuzzySuggestModal`, `Notice`, `metadataCache.getFirstLinkpathDest`, `vault.cachedRead/readBinary`, `Vault.recurseChildren`, `workspace.on('file-menu'|'editor-menu')`, `addRibbonIcon`, `addCommand`) but their exact signatures are unverified against the real typings. Please run `npm install && npm run build` once; if TypeScript reports an error with the real `obsidian` types, it will point at the exact line. The prebuilt `main.js` is already bundled, so most users just copy it.
2. **Browsers**: only Chromium was tested. Firefox/Safari/Edge should behave the same (everything is plain scripts, no ES modules, no `fetch` on local files) but are untested.
3. **PDF.js runs without a separate worker thread** when opened from `file://` (the browser blocks that), so very large PDFs can briefly freeze the page. No CJK font-maps are bundled: PDFs that depend on non-embedded CJK fonts may render with fallback fonts.
4. **Data volume**: for local PDFs a base64 copy (`.pdf.js`, +33 %) is written next to each PDF because browsers cannot read local files via `fetch`. The original PDF is kept for download.
5. **Browser storage on `file://`**: Chromium allows it; some browsers don't. Then progress/bookmarks/theme last for the tab only (the site says so).
6. **Fonts**: system font stacks only (nothing is downloaded), so the typeface varies by device.
7. **Not supported**: footnotes, Mermaid rendering (source shown), Dataview/other plugin output, syntax-highlight colours, `.canvas`/`.base` files, remote images (placeholder with link).
8. **Embedded single-file mode** makes large files: base64 adds ~33 %, plus ~2.3 MB when the page contains PDFs. Browsers may struggle above roughly 150 MB; the plugin warns.
