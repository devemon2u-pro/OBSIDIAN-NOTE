# User guide

## Open the plugin
Click the **graduation-cap ribbon icon**, or press `Ctrl/Cmd+P` and run **Open Learning Website Builder**. The wizard has 7 steps; you can go back at any time.

## 1. Export type
- **Complete learning website**: homepage + one page per course + search, categories, bookmarks. Open `index.html`.
- **Individual HTML**: one note or course as one page. Tick *Embed everything* for a single standalone file (PDFs, audio, video, images inside), or untick it for a page plus a `_assets` folder (better for large media).

## 2. Select folders and notes (course manager)
- **Add folder…** – the folder becomes a *course*; every note inside (including sub-folders) becomes a *lesson*. Sub-folder names become sidebar group headings.
- **Add note…** – a single note becomes a one-lesson course.
- **Add every top-level folder** – quick way to build a library.
- For every course you can: rename it, set an emoji/icon, set a **category** (used for filters and the Courses menu), edit the **description**, mark it **Featured**, **reorder** (arrows) and **remove** it.
- The list is remembered, so *Update Existing Website* can reuse it later.
- Only attachments that selected notes **link or embed** are exported. Nothing else from your vault is copied.

## 3. Design
Pick a **preset** (Academic Indigo, Midnight Studio, Forest Scholar, Sunrise Workshop), then adjust: title, description, **logo** (an image from your vault), default theme (light / dark / system), accent colour, homepage layout, course-card style, font, navigation style, corner roundness, breadcrumbs, previous/next course buttons, footer text. The preview on the right updates immediately.

Fonts use each viewer's own system fonts (nothing is downloaded), so the exact typeface depends on their device.

## 4. Media and attachments
Choose which file types to include (PDF, audio, video, other). The plugin scans your notes and shows counts, sizes, the estimated output size, and **warnings** (missing files, remote images, very large files).

## 5. Preview
See the summary and the homepage. **Open full preview in browser** builds a real temporary copy and opens it.

## 6. Export
Choose the **output folder** (type a full path or click Browse) and click **Start export**. Progress and errors are shown.

## 7. Finished
Shows where the files are, with buttons to open the website or the folder, and usage instructions.

## Commands (Ctrl/Cmd+P)
| Command | What it does |
|---|---|
| Open Learning Website Builder | The wizard |
| Export Current Note as HTML | Quick single-page export of the open note |
| Export Selected Folder as Website | Pick a folder; sub-folders become courses |
| Export Entire Website | Exports your saved course list |
| Preview Website | Builds a temporary copy and opens it |
| Update Existing Website | Re-exports your saved courses into the last output folder, removing files it generated earlier that are no longer needed (it never deletes other files) |
| Open Export Folder | Opens the last output folder |

Right-click a note, a folder, or inside the editor for export shortcuts.

## Using the exported website
- **Open `index.html`** with a double-click. Keep `index.html`, `pages/` and `assets/` together; copy the folder to a USB drive or another computer freely.
- **Search**: `Ctrl/Cmd+K` or `/` (all courses and lessons, with snippets).
- **Library** (bookmark icon): bookmarks, recently opened lessons, favourite courses.
- **Course page**: lesson list, table of contents, reading-progress bar, *Mark complete* (also automatic after scrolling through a long lesson), *Bookmark*, *Focus* (hides navigation; Esc exits), *Print*.
- **PDF viewer**: previous/next, page box, zoom, fit width/page, fullscreen, search with highlighting, download.
- **Audio/video**: play/pause, seek, volume, speed, time, download (video also fullscreen).
- **Theme**: sun / moon / monitor buttons (light / dark / system).
- Progress, bookmarks and theme are stored in the browser. Some browsers restrict storage for local `file://` pages; the site then keeps them for the current tab only and tells you so.

## What converts, and what shows a fallback
Supported: headings, paragraphs, bold/italic/strikethrough/highlight, lists, nested lists, checklists, tables (with alignment), blockquotes, code blocks (with copy button), callouts (all common types, foldable), wikilinks (`[[Note]]`, `[[Note#Heading|alias]]`), links between courses, images (with sizes), PDF/audio/video embeds, note embeds (`![[Note]]`, `![[Note#Heading]]`, `![[Note#^block]]`), math (`$…$`, `$$…$$`, bundled KaTeX), tags, `%%comments%%`, front-matter (`title`, `description`).

Visible fallbacks instead of silent loss: links to notes outside the export, missing files, remote images, Mermaid (shown as source), unsupported attachments (download card). Not supported: footnotes, Dataview/other plugin output, syntax highlighting colours, canvas/base files.

## Troubleshooting
- *"Choose an output folder"* – enter a full path such as `C:\Users\me\Site` or `/Users/me/Site`.
- *Video won't play* – browsers only play codecs they support (MP4/H.264 and WebM are safest). Use the download button.
- *Huge HTML file* – untick *Embed everything* or drop big media.
- *A PDF with unusual fonts looks different* – the viewer uses the standard PDF.js without extra CJK font maps.
