# Offline Learning Website Builder (Obsidian plugin)

Turn Obsidian folders, notes, PDFs, images, audio and video into a polished **offline learning website**: homepage, course pages, search, light/dark themes, bookmarks, progress tracking and a built-in **PDF.js viewer** (no more "This plugin is not supported").

**Quick start**: read `INSTALL.md` (copy 3 files into your vault's `.obsidian/plugins` folder), then `USER_GUIDE.md`.

- Two export modes: **complete website** (`index.html` + `pages/` + `assets/`) or **individual HTML** (one file with everything embedded, or page + assets folder).
- Works from `file://` — no server, CDN, online fonts, API keys or internet.
- Visual 7-step wizard, course manager, visual designer with 4 presets and live preview.
- Safe by design: note HTML is escaped, links are validated, only selected notes and the attachments they link are exported.

See `TESTING_REPORT.md` for exactly what was tested and what was not, and `FILE_MANIFEST.md` for the project layout.
License: MIT. Bundles PDF.js (Apache-2.0, Mozilla) and KaTeX (MIT).
