// Runs the end-to-end tests: builds a fixture vault, exports it in all three modes, then checks the result in Chromium over file:// URLs.
// Needs the optional dependencies (pdf-lib, sharp, playwright) and ffmpeg on PATH.
import { execSync } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
const T = fs.mkdtempSync(path.join(os.tmpdir(), "olwb-test-"));
const sh = (c) => execSync(c, { stdio: "inherit", env: { ...process.env, NODE_GLOBAL: path.resolve("node_modules") } });
sh("node esbuild.config.mjs test");
sh(`node tests/make-fixture.cjs ${T}/vault`);
sh(`node tests/.build/export-fixture.cjs ${T}/vault ${T}/site site 0`);
sh(`node tests/.build/export-fixture.cjs ${T}/vault ${T}/single-embed single 1`);
sh(`node tests/.build/export-fixture.cjs ${T}/vault ${T}/single-local single 0`);
sh(`node tests/browser-test.cjs ${T}/site ${T}/single-embed/physics-mechanics.html ${T}/single-local/physics-mechanics.html ${T}/shots`);
console.log("Screenshots:", path.join(T, "shots"));
