// Builds the offline libraries that get embedded into exported websites.
// Run with:  npm run vendor   (needs devDependencies pdfjs-dist + katex; output is committed in src/vendor/)
import { createRequire } from "module";
import { build } from "esbuild";
import fs from "fs";
import path from "path";

const require = createRequire(process.env.VENDOR_RESOLVE_FROM || import.meta.url);
const pkgDir = (name) => path.dirname(require.resolve(`${name}/package.json`));
const out = path.resolve("src/vendor");
fs.mkdirSync(out, { recursive: true });

const pdfDir = pkgDir("pdfjs-dist");
const legacy = path.join(pdfDir, "legacy/build");
fs.writeFileSync(path.join(out, "_pdf-entry.mjs"), `export * from ${JSON.stringify(path.join(legacy, "pdf.min.mjs"))};`);
await build({ entryPoints: [path.join(out, "_pdf-entry.mjs")], bundle: true, format: "iife", globalName: "pdfjsLib", minify: true, legalComments: "none", outfile: path.join(out, "pdfjs-lib.js.txt") });
fs.unlinkSync(path.join(out, "_pdf-entry.mjs"));
fs.copyFileSync(path.join(legacy, "pdf.worker.min.mjs"), path.join(out, "pdf-worker.mjs.txt"));

const kdir = path.join(pkgDir("katex"), "dist");
fs.copyFileSync(path.join(kdir, "katex.min.js"), path.join(out, "katex.min.js.txt"));
let css = fs.readFileSync(path.join(kdir, "katex.min.css"), "utf8");
css = css.replace(/url\(([^)]+?\.woff2)\)\s*format\("woff2"\)\s*,\s*url\([^)]+?\.woff\)\s*format\("woff"\)\s*,\s*url\([^)]+?\.ttf\)\s*format\("truetype"\)/g, (_m, u) => {
	const file = path.join(kdir, u.replace(/["']/g, ""));
	return `url(data:font/woff2;base64,${fs.readFileSync(file).toString("base64")}) format("woff2")`;
});
fs.writeFileSync(path.join(out, "katex.css.txt"), css);
console.log("vendor files written to", out);
