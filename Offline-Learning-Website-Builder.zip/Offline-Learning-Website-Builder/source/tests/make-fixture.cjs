// Builds a small Obsidian-like vault with REAL attachments (pdf, wav, webm, png) for end-to-end tests.
const fs = require("fs"), path = require("path"), cp = require("child_process");
const G = process.env.NODE_GLOBAL || "/home/claude/.npm-global/lib/node_modules";
const root = process.argv[2];
fs.rmSync(root, { recursive: true, force: true });
const w = (p, t) => { fs.mkdirSync(path.dirname(path.join(root, p)), { recursive: true }); fs.writeFileSync(path.join(root, p), t); };
(async () => {
	const { PDFDocument, StandardFonts } = require(G + "/pdf-lib");
	const d = await PDFDocument.create(); const f = await d.embedFont(StandardFonts.Helvetica);
	for (let i = 1; i <= 3; i++) d.addPage([420, 540]).drawText(`Page ${i}: offline pdf needle${i}`, { x: 30, y: 480, size: 20, font: f });
	fs.mkdirSync(path.join(root, "attachments"), { recursive: true });
	fs.writeFileSync(path.join(root, "attachments/Lecture Notes.pdf"), await d.save());
	const sharp = require(G + "/sharp");
	await sharp({ create: { width: 320, height: 200, channels: 3, background: { r: 40, g: 120, b: 220 } } }).png().toFile(path.join(root, "attachments/diagram.png"));
	await sharp({ create: { width: 64, height: 64, channels: 3, background: { r: 220, g: 60, b: 90 } } }).png().toFile(path.join(root, "attachments/logo.png"));
	cp.execSync(`ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=440:duration=3" "${root}/attachments/tone.wav"`);
	cp.execSync(`ffmpeg -loglevel error -y -f lavfi -i testsrc=duration=2:size=320x180:rate=15 -f lavfi -i sine=frequency=330:duration=2 -c:v libvpx -b:v 200k -c:a libvorbis -shortest "${root}/attachments/clip.webm"`);
	w("Physics/Mechanics/01 Introduction.md", `---
title: Introduction to Mechanics
description: Motion, forces and energy.
---
# Introduction to Mechanics

Welcome! This is **bold**, *italic*, ~~strike~~, ==highlight== and \`inline code\`. Tag: #physics/basics

> [!tip] Study tip
> Read the [[02 Newton's Laws|laws]] next.

> [!warning]- Folded warning
> Hidden by default.

## Checklist
- [x] Read intro
- [ ] Solve problems
  - nested item

1. First
2. Second

| Quantity | Symbol | Unit |
|:--|:-:|--:|
| Force | F | N |
| Energy | E | J |

\`\`\`python
def f(x):
    return x ** 2   # <b>not html</b>
\`\`\`

Inline math $E = mc^2$ and block:

$$
\\int_0^1 x^2 \\, dx = \\frac{1}{3}
$$

## Media
![[Lecture Notes.pdf]]

![[Lecture Notes.pdf#page=2]]

![[tone.wav]]

![[clip.webm]]

![[diagram.png|200]]

![Alt text](attachments/diagram.png)

## Hostile content
<script>window.__pwned=1</script>
<img src=x onerror="window.__pwned=2">
[click](javascript:window.__pwned=3)
[[Missing Note]] and ![[nothing.png]]
![remote](https://example.com/x.png)
Link to [Optics](../Optics.md) and [[Optics#Lenses|lenses]].
`);
	w("Physics/Mechanics/02 Newton's Laws.md", `# Newton's Laws\n\nEmbedded note:\n\n![[03 Extra#Details]]\n\n## First law\nAn object stays at rest. See [[01 Introduction#Checklist]].\n\n## Second law\n$F = ma$\n`);
	w("Physics/Mechanics/03 Extra.md", `# Extra\n\n## Details\nTranscluded detail paragraph.\n\n## Other\nNot included.\n`);
	w("Physics/Optics.md", `# Optics\n\n## Lenses\nLight bends. Download [[Lecture Notes.pdf]].\n`);
	w("Chemistry/Atoms.md", `# Atoms\n\nAtoms are made of protons, neutrons and electrons. Search keyword: zirconium.\n`);
	w("Chemistry/Bonds.md", `# Bonds\n\nIonic and covalent bonds.\n`);
	w("বাংলা/নোট.md", `# বাংলা নোট\n\nএটি একটি পরীক্ষা।\n`);
	w("Standalone.md", `# Standalone\n\nJust one note with ![[diagram.png]] and a link [[Atoms]].\n`);
	console.log("fixture ready");
})();
