// Loads the REAL built main.js with a mock `obsidian` module and drives the Obsidian-facing glue (commands, adapter, export).
// This validates our own wiring, NOT compatibility with the real Obsidian API.
const Module = require("module"), path = require("path"), fs = require("fs");
const [mainJs, vaultDir, outDir] = process.argv.slice(2);
class TAbstractFile { constructor(p) { this.path = p; this.name = p.split("/").pop(); } }
class TFile extends TAbstractFile { constructor(p, size) { super(p); const i = this.name.lastIndexOf("."); this.extension = this.name.slice(i + 1); this.basename = this.name.slice(0, i); this.stat = { size }; } }
class TFolder extends TAbstractFile { constructor(p) { super(p); this.children = []; } isRoot() { return this.path === "/"; } }
class Vault { static recurseChildren(root, cb) { const w = (f) => { cb(f); (f.children || []).forEach(w); }; w(root); } }
const noop = function () { return this; };
const mock = { TAbstractFile, TFile, TFolder, Vault, Notice: class { hide() {} setMessage() {} }, Modal: class { constructor(app) { this.app = app; this.contentEl = {}; this.modalEl = {}; } }, FuzzySuggestModal: class { constructor(app) { this.app = app; } }, PluginSettingTab: class { constructor(a, p) { this.app = a; } }, Setting: class { constructor() {} setName() { return this; } }, setIcon() {},
	Plugin: class { constructor(app) { this.app = app; this.cmds = []; this.ribbon = []; this.events = []; this.store = null; } addCommand(c) { this.cmds.push(c); } addRibbonIcon(i, t, cb) { this.ribbon.push({ i, t, cb }); return {}; } registerEvent(e) { this.events.push(e); } addSettingTab() {} async loadData() { return this.store; } async saveData(d) { this.store = d; } } };
const orig = Module._load; Module._load = function (r, ...a) { return r === "obsidian" ? mock : orig.call(this, r, ...a); };

// fake vault from the fixture folder
const root = new TFolder("/"); const byPath = new Map(); const files = [];
const walk = (dir, parent) => { for (const e of fs.readdirSync(path.join(vaultDir, dir), { withFileTypes: true })) { const rel = dir ? dir + "/" + e.name : e.name; if (e.isDirectory()) { const f = new TFolder(rel); parent.children.push(f); byPath.set(rel, f); walk(rel, f); } else { const f = new TFile(rel, fs.statSync(path.join(vaultDir, rel)).size); parent.children.push(f); byPath.set(rel, f); files.push(f); } } };
walk("", root);
const app = {
	vault: { getAbstractFileByPath: (p) => byPath.get(p) ?? null, getRoot: () => root, getMarkdownFiles: () => files.filter((f) => f.extension === "md"), getFiles: () => files, getAllLoadedFiles: () => [root, ...byPath.values()],
		cachedRead: async (f) => fs.readFileSync(path.join(vaultDir, f.path), "utf8"), readBinary: async (f) => { const b = fs.readFileSync(path.join(vaultDir, f.path)); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); } },
	metadataCache: { getFirstLinkpathDest: (l, src) => { const cands = /\.[a-z0-9]{1,5}$/i.test(l) ? [l] : [l + ".md", l]; for (const c of cands) { if (byPath.has(c) && byPath.get(c) instanceof TFile) return byPath.get(c); const hit = files.find((f) => f.path.endsWith("/" + c)); if (hit) return hit; } return null; } },
	workspace: { getActiveFile: () => byPath.get("Standalone.md"), on: (n, cb) => ({ n, cb }) },
};
(async () => {
	let pass = 0, fail = 0; const ok = (n, c, x = "") => { c ? pass++ : fail++; console.log(`${c ? "PASS" : "FAIL"}  ${n}${c ? "" : " -> " + x}`); };
	const m = require(mainJs); const Plugin = m.default || m;
	ok("main.js exports a Plugin class", typeof Plugin === "function");
	const p = new Plugin(app, {});
	await p.onload();
	const ids = p.cmds.map((c) => c.id);
	ok("7 commands registered", ["open-builder", "export-current-note", "export-selected-folder", "export-entire-website", "preview-website", "update-existing-website", "open-export-folder"].every((i) => ids.includes(i)), ids.join(","));
	ok("ribbon icon registered", p.ribbon.length === 1);
	ok("context-menu events registered (file-menu, editor-menu)", p.events.length === 2);
	const chk = p.cmds.find((c) => c.id === "export-current-note").checkCallback;
	ok("export-current-note is available when a .md note is active", chk(true) === true);
	ok("settings default course list empty", Array.isArray(p.settings.courses) && p.settings.courses.length === 0);
	// drive the real exporter glue through the Obsidian adapter
	const { runExport } = require(path.resolve("tests/.build/obsidian-glue.cjs"));
	p.settings.courses = [{ id: "1", title: "Physics Mechanics", description: "", category: "Science", featured: true, kind: "folder", path: "Physics/Mechanics", icon: "" }, { id: "2", title: "Standalone", description: "", category: "Misc", featured: false, kind: "note", path: "Standalone.md", icon: "" }];
	const out = await runExport(p, { courses: p.settings.courses, design: p.settings.design, options: { ...p.settings.options, mode: "site" }, outputDir: outDir });
	ok("Obsidian adapter + exporter wrote a website", fs.existsSync(path.join(outDir, "index.html")) && out.plan.stats.courses === 2, JSON.stringify(out.plan.stats));
	ok("PDF + audio + video assets copied", fs.readdirSync(path.join(outDir, "assets/pdf")).some((f) => f.endsWith(".pdf")) && fs.readdirSync(path.join(outDir, "assets/audio")).length === 1 && fs.readdirSync(path.join(outDir, "assets/video")).length === 1);
	ok("settings remember last export", p.settings.lastExport && p.settings.lastExport.outputDir === outDir && p.store.lastExport.mode === "site");
	let threw = false; try { await runExport(p, { courses: p.settings.courses, design: p.settings.design, options: p.settings.options, outputDir: "relative/path" }); } catch { threw = true; }
	ok("relative output folder rejected", threw);
	// unrelated vault file must not leak
	const leaked = fs.readdirSync(path.join(outDir, "assets"), { recursive: true }).some((f) => /logo/.test(String(f)));
	ok("unlinked attachments are NOT exported (logo.png not linked)", !leaked);
	// update flow removes stale generated files
	fs.writeFileSync(path.join(outDir, "pages/stale.html"), "x"); const man = JSON.parse(fs.readFileSync(path.join(outDir, ".olwb-manifest.json"), "utf8")); man.files.push("pages/stale.html"); fs.writeFileSync(path.join(outDir, ".olwb-manifest.json"), JSON.stringify(man));
	fs.writeFileSync(path.join(outDir, "my-own-file.txt"), "keep me");
	await runExport(p, { courses: p.settings.courses, design: p.settings.design, options: { ...p.settings.options, mode: "site" }, outputDir: outDir });
	ok("update removes stale generated file", !fs.existsSync(path.join(outDir, "pages/stale.html")));
	ok("update never deletes user's own files", fs.existsSync(path.join(outDir, "my-own-file.txt")));
	console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
