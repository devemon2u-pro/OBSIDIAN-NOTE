// Only used for offline type-checking in environments without @types/node.
declare const Buffer: any;
declare module "fs" { const x: any; export = x; }
declare module "path" { const x: any; export = x; }
declare module "os" { const x: any; export = x; }
