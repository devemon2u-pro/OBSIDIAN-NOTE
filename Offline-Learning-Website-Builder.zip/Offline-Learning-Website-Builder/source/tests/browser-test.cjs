// End-to-end browser tests over file:// URLs (Chromium via Playwright).  node tests/browser-test.cjs <siteDir> <singleEmbedHtml> <singleLocalHtml> <shotsDir>
const G = process.env.NODE_GLOBAL || "/home/claude/.npm-global/lib/node_modules";
const { chromium } = require(G + "/playwright");
const [site, embedFile, localFile, shots] = process.argv.slice(2);
require("fs").mkdirSync(shots, { recursive: true });
let pass = 0, fail = 0;
const ok = (name, cond, extra = "") => { (cond ? pass++ : fail++); console.log(`${cond ? "PASS" : "FAIL"}  ${name}${cond ? "" : "  -> " + extra}`); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function newPage(browser, errors, requests, opts = {}) {
	const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, colorScheme: "light", ...opts });
	const p = await ctx.newPage();
	p.on("pageerror", (e) => errors.push(e.message));
	p.on("console", (m) => { if (m.type() === "error") errors.push("console: " + m.text()); });
	p.on("request", (r) => { if (/^https?:/.test(r.url())) requests.push(r.url()); });
	return p;
}

(async () => {
	const browser = await chromium.launch();
	const errors = [], requests = [];
	let p = await newPage(browser, errors, requests);

	// ---------------- HOME ----------------
	await p.goto("file://" + site + "/index.html");
	ok("home: title", (await p.title()) === "Test Academy");
	ok("home: 4 course cards in catalog", (await p.locator("#olwb-all-courses .card").count()) === 4);
	ok("home: featured section shows the featured course", (await p.locator('h2:text("Featured courses")').count()) === 1);
	ok("home: stats rendered", /4/.test(await p.locator(".stats").innerText()));
	await p.screenshot({ path: shots + "/home-light.png" });

	// theme
	await p.click('[data-theme-set="dark"]');
	ok("theme: dark applied", (await p.getAttribute("html", "data-theme")) === "dark");
	await p.screenshot({ path: shots + "/home-dark.png" });
	await p.reload();
	ok("theme: dark persisted after reload (storage or fallback)", (await p.getAttribute("html", "data-theme")) === "dark");
	await p.click('[data-theme-set="light"]');
	ok("theme: light applied", (await p.getAttribute("html", "data-theme")) === "light");
	await p.click('[data-theme-set="system"]');
	ok("theme: system follows OS (light here)", (await p.getAttribute("html", "data-theme")) === "light");

	// filter + favourite
	await p.click('.chip[data-cat="Languages"]');
	ok("filter: category chip hides others", (await p.locator("#olwb-all-courses .card:visible").count()) === 1);
	await p.click('.chip[data-cat=""]');
	await p.fill("#olwb-hero-search", "chem");
	ok("filter: hero search narrows cards", (await p.locator("#olwb-all-courses .card:visible").count()) === 1);
	await p.fill("#olwb-hero-search", "");
	await p.click('#olwb-all-courses .card[data-slug="chemistry"] .fav');
	ok("favourite: favourites section appears", await p.locator("#olwb-favs").isVisible());
	await p.screenshot({ path: shots + "/home-fav.png" });

	// global search from home
	await p.keyboard.press("Control+k");
	await p.keyboard.type("zirconium");
	await p.waitForSelector(".result");
	ok("search: finds lesson text across courses", /Atoms/.test(await p.locator(".result").first().innerText()));
	await p.screenshot({ path: shots + "/search.png" });
	await p.keyboard.press("Enter");
	await p.waitForURL(/chemistry\.html#atoms/);
	ok("search: Enter navigates to course page lesson", /chemistry\.html#atoms/.test(p.url()));
	ok("course: Chemistry lesson visible", await p.locator("#atoms.active").isVisible());

	// ---------------- COURSE PAGE ----------------
	await p.goto("file://" + site + "/pages/physics-mechanics.html");
	ok("course: first lesson active", await p.locator(".lesson.active").count() === 1);
	ok("course: sidebar lists 3 lessons", (await p.locator(".lesson-link").count()) === 3);
	ok("course: nav has Home + Courses + next course", (await p.locator('.topnav a:text("Home")').count()) === 1 && (await p.locator('.topnav a:text("Next course")').count()) === 1);
	ok("course: breadcrumb", /Home.*Science.*Physics Mechanics/s.test(await p.locator(".crumbs").innerText()));
	ok("course: next-course link is relative and works", /^\.\.\/pages\/chemistry\.html$/.test(await p.getAttribute('.topnav a[title^="Next course"]', "href")));
	ok("course: logo embedded", (await p.locator(".brand img").count()) === 1 && (await p.locator(".brand img").evaluate((i) => i.naturalWidth)) > 0);
	ok("md: callout, foldable callout, table, code, tags", (await p.locator(".callout").count()) === 2 && (await p.locator("details.callout").count()) === 1 && (await p.locator("table").count()) === 1 && (await p.locator(".codeblock code").count()) === 1 && (await p.locator(".tag").count()) >= 1);
	ok("md: task list checked state", (await p.locator("li.task input:checked").count()) === 1 && (await p.locator("li.task input").count()) === 2);
	ok("md: inline + block math rendered by bundled KaTeX", (await p.locator(".math .katex").count()) >= 2, "katex count " + (await p.locator(".math .katex").count()));
	ok("md: wikilink resolved to lesson", /#02-newton-s-laws$/.test(await p.getAttribute('.callout a.internal', "href")));
	ok("md: unresolved link & missing embed fallbacks visible", (await p.locator(".unresolved").count()) >= 4);
	ok("security: no injected script ran", (await p.evaluate(() => window.__pwned)) === undefined);
	ok("security: no javascript: links, no onerror attrs", (await p.locator('a[href^="javascript"], [onerror]').count()) === 0);
	ok("md: images load (embed + markdown syntax)", (await p.locator(".prose img").evaluateAll((a) => a.every((i) => i.complete && i.naturalWidth > 0))) && (await p.locator(".prose img").count()) === 2);
	ok("md: copy button on code", (await p.locator(".codeblock .copy").count()) === 1);
	await p.screenshot({ path: shots + "/course-top.png" });

	// PDF viewer
	const pdf = p.locator(".olwb-pdf").first();
	await pdf.scrollIntoViewIfNeeded();
	await p.waitForSelector(".olwb-pdf canvas", { timeout: 15000 }).catch(() => {});
	ok("pdf: two viewers on page", (await p.locator(".olwb-pdf").count()) === 2);
	ok("pdf: renders a canvas (bundled PDF.js)", (await pdf.locator("canvas").count()) === 1);
	ok("pdf: page count shown", /3/.test(await pdf.locator(".pdf-bar .cnt").first().innerText()), await pdf.locator(".pdf-bar").innerText());
	ok("pdf: canvas has non-white content", await pdf.locator("canvas").evaluate((c) => { const d = c.getContext("2d").getImageData(0, 0, c.width, c.height).data; for (let i = 0; i < d.length; i += 4) if (d[i] < 128) return true; return false; }));
	ok("pdf: text layer present", (await pdf.locator(".textLayer span").count()) > 0);
	const w0 = await pdf.locator("canvas").evaluate((c) => c.clientWidth);
	await pdf.locator('button[aria-label="Next page"]').click(); await sleep(600);
	ok("pdf: next page -> 2", (await pdf.locator("input.pg").inputValue()) === "2");
	await pdf.locator('button[aria-label="Zoom in"]').click(); await sleep(600);
	ok("pdf: zoom in enlarges page", (await pdf.locator("canvas").evaluate((c) => c.clientWidth)) > w0);
	await pdf.locator('button[aria-label="Fit to page"]').click(); await sleep(600);
	await pdf.locator('button[aria-label="Fit to width"]').click(); await sleep(600);
	ok("pdf: fit to width restores width", Math.abs((await pdf.locator("canvas").evaluate((c) => c.clientWidth)) - w0) < 4);
	await pdf.locator("input.pg").fill("3"); await pdf.locator("input.pg").press("Enter"); await sleep(600);
	ok("pdf: page number navigation -> 3", (await pdf.locator("input.pg").inputValue()) === "3");
	await pdf.locator("input.q").fill("needle1"); await pdf.locator("input.q").press("Enter"); await sleep(1200);
	ok("pdf: search jumps to page 1 and highlights", (await pdf.locator("input.pg").inputValue()) === "1" && (await pdf.locator(".textLayer mark").count()) >= 1, await pdf.locator(".pdf-bar").innerText());
	await pdf.screenshot({ path: shots + "/pdf-viewer.png" });
	ok("pdf: second viewer opened at #page=2", await (async () => { const v2 = p.locator(".olwb-pdf").nth(1); await v2.scrollIntoViewIfNeeded(); await sleep(1500); return (await v2.locator("input.pg").inputValue()) === "2"; })());
	const dlh = await pdf.locator('.pdf-bar a[download]').getAttribute("href");
	ok("pdf: download link points at original file", /lecture-notes-.*\.pdf$/.test(dlh), dlh);
	const fsOk = await pdf.locator('button[aria-label="Fullscreen"]').click().then(() => sleep(500)).then(() => p.evaluate(() => !!document.fullscreenElement)).catch(() => false);
	ok("pdf: fullscreen request works", fsOk);
	await p.keyboard.press("Escape").catch(() => {}); await p.evaluate(() => document.fullscreenElement && document.exitFullscreen()).catch(() => {});

	// audio / video
	const au = p.locator(".olwb-audio"), vi = p.locator(".olwb-video");
	await au.scrollIntoViewIfNeeded(); await sleep(800);
	ok("audio: custom player with controls", (await au.locator("audio").count()) === 1 && (await au.locator("input.seek").count()) === 1 && (await au.locator("select").count()) === 1 && (await au.locator('a[download]').count()) === 1);
	ok("audio: duration loaded (3s wav)", (await au.locator(".time").nth(1).innerText()) === "0:03", await au.locator(".player").innerText());
	await au.locator('button[aria-label="Play"]').click(); await sleep(900);
	ok("audio: plays", await au.locator("audio").evaluate((a) => a.currentTime > 0 && !a.paused), "not playing");
	await au.locator("select").selectOption("1.5");
	ok("audio: playback speed", (await au.locator("audio").evaluate((a) => a.playbackRate)) === 1.5);
	await au.locator('button[aria-label="Play"], button[aria-label="Pause"]').first().click();
	await vi.scrollIntoViewIfNeeded(); await sleep(800);
	ok("video: duration loaded (2s webm)", /0:0[12]/.test(await vi.locator(".time").nth(1).innerText()), await vi.locator(".player").innerText());
	ok("video: fullscreen + speed + volume + download controls", (await vi.locator('button[aria-label="Fullscreen"]').count()) === 1 && (await vi.locator("input.vol").count()) === 1 && (await vi.locator("a[download]").count()) === 1);
	await vi.locator(".vbig").click(); await sleep(900);
	ok("video: plays", await vi.locator("video").evaluate((v) => v.currentTime > 0), "not playing");
	await p.screenshot({ path: shots + "/course-media.png" });

	// navigation, toc, progress, bookmark, library
	await p.goto("file://" + site + "/pages/physics-mechanics.html#02-newton-s-laws");
	ok("route: hash opens the right lesson", await p.locator("#\\30 2-newton-s-laws.active").isVisible());
	ok("toc: built for the active lesson", (await p.locator("#olwb-toc a").count()) >= 2);
	ok("transclusion: embedded note section included", /Transcluded detail paragraph/.test(await p.locator(".embed-note").innerText()) && !/Not included/.test(await p.locator(".embed-note").innerText()));
	await p.click('.lesson.active [data-act="bookmark"]');
	await p.click('.lesson.active [data-act="done"]');
	ok("progress: lesson marked complete in sidebar", (await p.locator(".lesson-link.done").count()) === 1 && /33%/.test(await p.locator("#olwb-side-pct").innerText()));
	await p.click('[data-act="library"]'); await sleep(400);
	ok("library: bookmark + recent listed", (await p.locator(".drawer .item").count()) >= 2 && /Newton/.test(await p.locator(".drawer").innerText()));
	await p.screenshot({ path: shots + "/library.png" });
	await p.keyboard.press("Escape");
	await p.click('.lesson.active [data-act="focus"]');
	ok("focus mode hides nav", !(await p.locator(".topnav").isVisible()));
	await p.screenshot({ path: shots + "/focus.png" });
	await p.keyboard.press("Escape");
	ok("focus mode exits with Esc", await p.locator(".topnav").isVisible());
	await p.goto("file://" + site + "/index.html");
	ok("progress: shown on home card", (await p.locator('#olwb-all-courses .card[data-slug="physics-mechanics"] .pct').innerText()).includes("33%"));
	ok("home: 'continue learning' section appears", await p.locator("#olwb-continue").isVisible());

	// cross-course link + bengali + print css
	await p.goto("file://" + site + "/pages/standalone-note.html");
	ok("cross-course link: [[Atoms]] -> chemistry.html#atoms", (await p.getAttribute(".prose a.internal", "href")) === "chemistry.html#atoms");
	await p.goto("file://" + site + "/pages/course-17megcz.html");
	ok("unicode: Bengali course & lesson render", /বাংলা নোট/.test(await p.locator(".lesson.active").innerText()));
	await p.emulateMedia({ media: "print" });
	ok("print: nav hidden, lesson shown", !(await p.locator(".topnav").isVisible()) && (await p.locator(".lesson.active").isVisible()));
	await p.emulateMedia({ media: "screen" });

	// mobile
	const m = await newPage(browser, errors, requests, { viewport: { width: 390, height: 800 } });
	await m.goto("file://" + site + "/pages/physics-mechanics.html");
	ok("mobile: no horizontal overflow", (await m.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)), await m.evaluate(() => document.documentElement.scrollWidth));
	await m.click('[data-act="lessons"]'); await sleep(400);
	ok("mobile: lesson drawer opens", await m.locator("#olwb-sidebar.open").count() === 1);
	await m.screenshot({ path: shots + "/mobile-course.png" });
	const mh = await newPage(browser, errors, requests, { viewport: { width: 390, height: 800 } });
	await mh.goto("file://" + site + "/index.html");
	ok("mobile: home no horizontal overflow", await mh.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1));
	await mh.screenshot({ path: shots + "/mobile-home.png" });

	// ---------------- SINGLE EMBEDDED ----------------
	for (const [label, file] of [["single-embedded", embedFile], ["single+assets-folder", localFile]]) {
		const q = await newPage(browser, errors, requests);
		await q.goto("file://" + file);
		ok(`${label}: opens, 3 lessons, no Home link`, (await q.locator(".lesson-link").count()) === 3 && (await q.locator('.topnav a:text("Home")').count()) === 0);
		ok(`${label}: images`, await q.locator(".prose img").evaluateAll((a) => a.length === 2 && a.every((i) => i.complete && i.naturalWidth > 0)));
		await q.locator(".olwb-pdf").first().scrollIntoViewIfNeeded();
		await q.waitForSelector(".olwb-pdf canvas", { timeout: 15000 }).catch(() => {});
		ok(`${label}: PDF renders`, (await q.locator(".olwb-pdf canvas").count()) >= 1 && /3/.test(await q.locator(".olwb-pdf .cnt").first().innerText()));
		await q.locator(".olwb-audio").scrollIntoViewIfNeeded(); await sleep(600);
		await q.locator('.olwb-audio button[aria-label="Play"]').click(); await sleep(1000);
		ok(`${label}: audio plays`, await q.locator(".olwb-audio audio").evaluate((a) => a.currentTime > 0));
		await q.locator(".olwb-video").scrollIntoViewIfNeeded(); await q.locator(".vbig").click(); await sleep(1000);
		ok(`${label}: video plays`, await q.locator(".olwb-video video").evaluate((v) => v.currentTime > 0));
		ok(`${label}: math`, (await q.locator(".math .katex").count()) >= 2);
		await q.keyboard.press("Control+k"); await q.keyboard.type("transcluded"); await sleep(500);
		ok(`${label}: in-page search`, (await q.locator(".result").count()) >= 1);
		await q.keyboard.press("Escape");
		if (label === "single-embedded") {
			const dl = q.locator('.olwb-pdf a[download]').first();
			const [d] = await Promise.all([q.waitForEvent("download", { timeout: 5000 }).catch(() => null), dl.click()]);
			ok(`${label}: embedded PDF download works`, !!d && /pdf/i.test(d.suggestedFilename()), d ? d.suggestedFilename() : "no download");
			await q.screenshot({ path: shots + "/single-embedded.png" });
		}
	}

	ok("offline: zero http(s) requests during all tests", requests.length === 0, requests.slice(0, 3).join(", "));
	const real = errors.filter((e) => !/Setting up fake worker|Failed to load resource.*file:/.test(e));
	ok("no uncaught JS errors", real.length === 0, real.slice(0, 4).join(" | "));
	console.log(`\n${pass} passed, ${fail} failed`);
	await browser.close();
	process.exit(fail ? 1 : 0);
})();
