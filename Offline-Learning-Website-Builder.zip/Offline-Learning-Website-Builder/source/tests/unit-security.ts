import * as fs from "fs"; import * as path from "path"; import * as os from "os";
import { FolderAdapter, NodeWriter } from "../src/core/nodeio";
import { planSite } from "../src/core/builder";
import { defaultDesign, defaultOptions, PRESETS, applyPreset } from "../src/core/design";
import { previewHomeHtml } from "../src/core/preview";
let pass = 0, fail = 0; const ok = (n: string, c: boolean, x = "") => { c ? pass++ : fail++; console.log(`${c ? "PASS" : "FAIL"}  ${n}${c ? "" : " -> " + x}`); };
(async () => {
	const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "olwb-sec-"));
	fs.writeFileSync(path.join(tmp, "secret.txt"), "TOP SECRET");
	const vault = path.join(tmp, "vault"); fs.mkdirSync(vault);
	fs.writeFileSync(path.join(vault, "n.md"), "# N\n![](../secret.txt)\n![[../secret.txt]]\n[[../secret.txt]]\n[x](../secret.txt)\n![](/etc/passwd)\n[[..\\..\\secret.txt]]\n");
	const plan = await planSite({ adapter: new FolderAdapter(vault), courses: [{ id: "1", title: "T", description: "", category: "c", featured: false, kind: "note", path: "n.md", icon: "" }], design: defaultDesign(), options: defaultOptions() });
	ok("path traversal links never become assets", plan.assets.length === 0, JSON.stringify(plan.assets));
	ok("path traversal content not present in HTML", !plan.pages.some((p) => p.html.includes("TOP SECRET")));
	const w = new NodeWriter(path.join(tmp, "out"));
	for (const bad of ["../escape.txt", "a/../../escape.txt", "/abs.txt", "..\\win.txt"]) {
		let threw = false; try { await w.writeText(bad, "x"); } catch { threw = true; }
		ok(`NodeWriter rejects ${JSON.stringify(bad)}`, threw && !fs.existsSync(path.join(tmp, "escape.txt")) && !fs.existsSync("/abs.txt"));
	}
	let rootThrew = false; try { new NodeWriter("/"); } catch { rootThrew = true; }
	ok("NodeWriter refuses a drive root", rootThrew);
	fs.mkdirSync("/tmp/olwb-presets", { recursive: true });
	for (const p of PRESETS) {
		const d = applyPreset({ ...defaultDesign(), title: "Preview " + p.name }, p.id);
		fs.writeFileSync(`/tmp/olwb-presets/${p.id}.html`, previewHomeHtml(d, [
			{ title: "Physics", description: "Motion and forces", category: "Science", featured: true, icon: "⚛", lessons: 12, minutes: 90 },
			{ title: "Mathematics", description: "Calculus and algebra", category: "Science", featured: false, icon: "∑", lessons: 20, minutes: 140 },
			{ title: "History", description: "World history notes", category: "Humanities", featured: false, icon: "", lessons: 8, minutes: 40 }], null));
	}
	ok("preview HTML generated for all presets", PRESETS.length >= 3 && fs.readdirSync("/tmp/olwb-presets").length === PRESETS.length);
	console.log(`\n${pass} passed, ${fail} failed`); process.exit(fail ? 1 : 0);
})();
