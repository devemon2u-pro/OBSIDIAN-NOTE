import { FolderAdapter, NodeWriter } from "../src/core/nodeio";
import { planSite, writePlan } from "../src/core/builder";
import { defaultDesign, defaultOptions, applyPreset } from "../src/core/design";
import type { CourseConfig } from "../src/core/types";

const [, , vault, out, mode, embed, preset] = process.argv;
const c = (id: string, title: string, path: string, kind: "folder" | "note", category: string, featured = false): CourseConfig => ({ id, title, description: "", category, featured, kind, path, icon: "" });
(async () => {
	const adapter = new FolderAdapter(vault);
	let design = defaultDesign();
	design.title = "Test Academy"; design.logoPath = "attachments/logo.png"; design.footerText = "© Test";
	if (preset) design = applyPreset(design, preset);
	const options = { ...defaultOptions(), mode: (mode as "site" | "single") || "site", embed: embed === "1" };
	const courses = mode === "single"
		? [c("1", "Physics Mechanics", "Physics/Mechanics", "folder", "Science")]
		: [c("1", "Physics Mechanics", "Physics/Mechanics", "folder", "Science", true), c("2", "Chemistry", "Chemistry", "folder", "Science"), c("3", "Standalone Note", "Standalone.md", "note", "Misc"), c("4", "বাংলা", "বাংলা", "folder", "Languages")];
	const plan = await planSite({ adapter, courses, design, options });
	const res = await writePlan(plan, adapter, new NodeWriter(out));
	console.log(JSON.stringify({ entry: res.entry, files: res.files, bytes: res.bytes, warnings: plan.warnings, est: plan.estimatedBytes, stats: plan.stats }));
})().catch((e) => { console.error("EXPORT FAILED", e); process.exit(1); });
