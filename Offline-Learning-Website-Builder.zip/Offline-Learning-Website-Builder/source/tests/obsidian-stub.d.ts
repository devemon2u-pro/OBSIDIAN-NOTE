// MINIMAL hand-written stand-in for the `obsidian` typings, used ONLY to catch plain TypeScript mistakes where the real package
// cannot be installed (offline). It is NOT proof of API compatibility: run `npm run build` with the real `obsidian` package.
declare module "obsidian" {
	export class TAbstractFile { path: string; name: string }
	export class TFile extends TAbstractFile { basename: string; extension: string; stat: { size: number } }
	export class TFolder extends TAbstractFile { children: TAbstractFile[]; isRoot(): boolean }
	export class Vault { static recurseChildren(root: TFolder, cb: (f: TAbstractFile) => unknown): void; getAbstractFileByPath(p: string): TAbstractFile | null; getRoot(): TFolder; getAllLoadedFiles(): TAbstractFile[]; getMarkdownFiles(): TFile[]; getFiles(): TFile[]; cachedRead(f: TFile): Promise<string>; readBinary(f: TFile): Promise<ArrayBuffer> }
	export class MetadataCache { getFirstLinkpathDest(l: string, s: string): TFile | null }
	export class MenuItem { setTitle(t: string): this; setIcon(i: string): this; onClick(cb: () => unknown): this }
	export class Menu { addItem(cb: (i: MenuItem) => unknown): this }
	export class Workspace {
		getActiveFile(): TFile | null;
		on(name: "file-menu", cb: (menu: Menu, file: TAbstractFile) => unknown): unknown;
		on(name: "editor-menu", cb: (menu: Menu, editor: unknown, view: { file: TFile | null }) => unknown): unknown;
	}
	export class App { vault: Vault; metadataCache: MetadataCache; workspace: Workspace }
	export class Notice { constructor(m: string, d?: number); hide(): void; setMessage(m: string): this }
	export class Modal { app: App; contentEl: HTMLElement; modalEl: HTMLElement; constructor(app: App); open(): void; close(): void; onOpen(): void; onClose(): void }
	export class FuzzySuggestModal<T> extends Modal { constructor(app: App); setPlaceholder(s: string): void; getItems(): T[]; getItemText(i: T): string; onChooseItem(i: T, e?: unknown): void }
	export interface Command { id: string; name: string; callback?: () => unknown; checkCallback?: (checking: boolean) => boolean | void }
	export class Plugin { app: App; constructor(...a: unknown[]); addRibbonIcon(i: string, t: string, cb: () => void): HTMLElement; addCommand(c: Command): Command; registerEvent(e: unknown): void; addSettingTab(t: PluginSettingTab): void; loadData(): Promise<unknown>; saveData(d: unknown): Promise<void> }
	export class PluginSettingTab { app: App; containerEl: HTMLElement; constructor(app: App, p: Plugin); display(): void }
	export class TextComponent { inputEl: HTMLInputElement; setValue(v: string): this; setPlaceholder(v: string): this; onChange(cb: (v: string) => unknown): this }
	export class TextAreaComponent { inputEl: HTMLTextAreaElement; setValue(v: string): this; onChange(cb: (v: string) => unknown): this }
	export class ToggleComponent { setValue(v: boolean): this; onChange(cb: (v: boolean) => unknown): this }
	export class DropdownComponent { addOption(k: string, v: string): this; setValue(v: string): this; onChange(cb: (v: string) => unknown): this }
	export class ColorComponent { setValue(v: string): this; onChange(cb: (v: string) => unknown): this }
	export class SliderComponent { setLimits(a: number, b: number, s: number | "any"): this; setValue(v: number): this; setDynamicTooltip(): this; onChange(cb: (v: number) => unknown): this }
	export class ButtonComponent { setButtonText(t: string): this; setCta(): this; setWarning(): this; onClick(cb: () => unknown): this }
	export class ExtraButtonComponent { setIcon(i: string): this; setTooltip(t: string): this; onClick(cb: () => unknown): this }
	export class Setting {
		constructor(el: HTMLElement); setName(s: string): this; setDesc(s: string): this; setHeading(): this;
		addText(cb: (t: TextComponent) => unknown): this; addTextArea(cb: (t: TextAreaComponent) => unknown): this; addToggle(cb: (t: ToggleComponent) => unknown): this;
		addDropdown(cb: (t: DropdownComponent) => unknown): this; addColorPicker(cb: (t: ColorComponent) => unknown): this; addSlider(cb: (t: SliderComponent) => unknown): this;
		addButton(cb: (b: ButtonComponent) => unknown): this; addExtraButton(cb: (b: ExtraButtonComponent) => unknown): this;
	}
	export function setIcon(el: HTMLElement, id: string): void;
}
interface HTMLElement { empty(): void; addClass(...c: string[]): void; removeClass(...c: string[]): void; createDiv(o?: any): HTMLDivElement; createSpan(o?: any): HTMLSpanElement; createEl<K extends keyof HTMLElementTagNameMap>(t: K, o?: any): HTMLElementTagNameMap[K]; setText(t: string): void }
