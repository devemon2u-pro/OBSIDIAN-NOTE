import esbuild from "esbuild";
import process from "process";
import { builtinModules } from "module";

const mode = process.argv[2];
const prod = mode === "production";

if (mode === "test") {
	// Bundles the Obsidian-free exporter for the end-to-end tests (see tests/).
	await esbuild.build({ entryPoints: ["tests/export-fixture.ts"], bundle: true, platform: "node", format: "cjs", loader: { ".txt": "text" }, outfile: "tests/.build/export-fixture.cjs", logLevel: "info" });
	process.exit(0);
}

const ctx = await esbuild.context({
	entryPoints: ["src/main.ts"],
	bundle: true,
	external: ["obsidian", "electron", "@codemirror/autocomplete", "@codemirror/collab", "@codemirror/commands", "@codemirror/language", "@codemirror/lint", "@codemirror/search", "@codemirror/state", "@codemirror/view", "@lezer/common", "@lezer/highlight", "@lezer/lr", ...builtinModules, ...builtinModules.map((m) => `node:${m}`)],
	format: "cjs",
	target: "es2020",
	platform: "node",
	loader: { ".txt": "text" },
	logLevel: "info",
	sourcemap: prod ? false : "inline",
	treeShaking: true,
	minify: prod,
	legalComments: "none",
	outfile: "main.js",
});
if (prod) { await ctx.rebuild(); process.exit(0); } else await ctx.watch();
