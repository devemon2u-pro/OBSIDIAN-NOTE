import OfflineLearningWebsiteBuilder from "./obsidian/main";
export default OfflineLearningWebsiteBuilder;
