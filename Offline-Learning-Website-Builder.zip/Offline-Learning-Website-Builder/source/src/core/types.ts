/** Shared types. The `core/` folder has NO dependency on Obsidian so it can be tested in plain Node. */

export type ThemeMode = "light" | "dark" | "system";
export type HeroLayout = "split" | "centered" | "compact";
export type CardStyle = "elevated" | "outlined" | "flat" | "cover";
export type FontChoice = "system" | "humanist" | "serif" | "rounded" | "mono";
export type NavStyle = "solid" | "glass";
export type AssetKind = "image" | "pdf" | "audio" | "video" | "other";

export interface CourseConfig {
	id: string;
	title: string;
	description: string;
	category: string;
	featured: boolean;
	/** "folder": every note inside (recursively) is a lesson. "note": a single-lesson course. */
	kind: "folder" | "note";
	/** Vault-relative path of the folder or note. */
	path: string;
	/** Optional emoji or 1-2 letters shown on the course card. */
	icon: string;
}

export interface DesignConfig {
	title: string;
	description: string;
	/** Vault path of a logo image (optional). */
	logoPath: string;
	theme: ThemeMode;
	preset: string;
	accent: string;
	heroLayout: HeroLayout;
	cardStyle: CardStyle;
	font: FontChoice;
	navStyle: NavStyle;
	radius: number;
	showBreadcrumb: boolean;
	showCourseNav: boolean;
	footerText: string;
}

export interface ExportOptions {
	/** "site" = Mode B (index + pages + assets). "single" = Mode A (one course/note). */
	mode: "site" | "single";
	/** Mode A only: embed every asset into the HTML file (base64). */
	embed: boolean;
	includePdf: boolean;
	includeAudio: boolean;
	includeVideo: boolean;
	includeOther: boolean;
	/** Files bigger than this (MB) trigger a warning. */
	largeFileMB: number;
	/** Max characters of each lesson put into the search index. */
	searchChars: number;
}

export interface VFile {
	path: string;
	name: string;
	basename: string;
	extension: string;
	size: number;
}

/** Everything the exporter needs from a vault. Implemented for Obsidian and for plain folders (tests). */
export interface VaultAdapter {
	readText(path: string): Promise<string>;
	readBinary(path: string): Promise<Uint8Array>;
	/** Resolve a wikilink/relative link the way Obsidian does. Must only return files that are inside the vault. */
	resolveLink(linkpath: string, sourcePath: string): VFile | null;
	getFile(path: string): VFile | null;
	/** All markdown notes inside a folder, recursively. */
	listNotes(folderPath: string): VFile[];
}

export interface OutputWriter {
	writeText(rel: string, content: string): Promise<void>;
	writeBinary(rel: string, data: Uint8Array): Promise<void>;
	remove(rel: string): Promise<void>;
	readText(rel: string): Promise<string | null>;
}

export interface AssetInfo {
	id: string;
	path: string;
	name: string;
	ext: string;
	kind: AssetKind;
	mime: string;
	size: number;
	/** Output path relative to the export root, e.g. assets/pdf/book-1a2b.pdf */
	outRel: string;
}

export interface Progress {
	phase: string;
	done: number;
	total: number;
	message?: string;
}
export type ProgressFn = (p: Progress) => void;

export interface LessonPlan {
	slug: string;
	title: string;
	group: string;
	path: string;
	html: string;
	text: string;
	headings: { level: number; text: string; id: string }[];
	words: number;
}

export interface CoursePlan {
	slug: string;
	config: CourseConfig;
	lessons: LessonPlan[];
	hue: number;
	needs: { math: boolean; pdf: boolean };
	minutes: number;
}

export interface PlannedPage {
	rel: string;
	html: string;
	needs: { math: boolean; pdf: boolean };
}

export interface SitePlan {
	options: ExportOptions;
	design: DesignConfig;
	entry: string;
	pages: PlannedPage[];
	courses: CoursePlan[];
	assets: AssetInfo[];
	logo: AssetInfo | null;
	warnings: string[];
	assetsRoot: string;
	estimatedBytes: number;
	stats: { courses: number; lessons: number; assets: number; assetBytes: number; words: number };
	siteDataJs: string;
	searchIndexJs: string;
	cssText: string;
}
