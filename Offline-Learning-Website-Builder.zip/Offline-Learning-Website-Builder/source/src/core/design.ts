import type { DesignConfig, ExportOptions, FontChoice } from "./types";

export interface Preset { id: string; name: string; blurb: string; design: Partial<DesignConfig> }

export const PRESETS: Preset[] = [
	{ id: "academic", name: "Academic Indigo", blurb: "Clean, bright and trustworthy. Elevated cards, split hero.", design: { accent: "#4f46e5", heroLayout: "split", cardStyle: "elevated", font: "system", radius: 14, navStyle: "solid", theme: "system" } },
	{ id: "midnight", name: "Midnight Studio", blurb: "Dark-first with a cyan accent. Outlined cards, centered hero.", design: { accent: "#0ea5e9", heroLayout: "centered", cardStyle: "outlined", font: "humanist", radius: 10, navStyle: "glass", theme: "dark" } },
	{ id: "forest", name: "Forest Scholar", blurb: "Calm green with serif text. Large cover cards.", design: { accent: "#15803d", heroLayout: "split", cardStyle: "cover", font: "serif", radius: 18, navStyle: "solid", theme: "light" } },
	{ id: "sunrise", name: "Sunrise Workshop", blurb: "Warm orange, rounded type, flat compact layout.", design: { accent: "#ea580c", heroLayout: "compact", cardStyle: "flat", font: "rounded", radius: 22, navStyle: "glass", theme: "system" } },
];

export const FONT_STACKS: Record<FontChoice, string> = {
	system: 'system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif',
	humanist: 'Seravek,"Gill Sans Nova",Ubuntu,Calibri,"Segoe UI","DejaVu Sans",sans-serif',
	serif: 'Charter,"Bitstream Charter","Sitka Text",Cambria,Georgia,"Times New Roman",serif',
	rounded: 'ui-rounded,"Hiragino Maru Gothic ProN",Quicksand,"Arial Rounded MT","Arial Rounded MT Bold",Calibri,"Segoe UI",sans-serif',
	mono: 'ui-monospace,"Cascadia Code","Source Code Pro",Menlo,Consolas,"DejaVu Sans Mono",monospace',
};
export const FONT_LABELS: Record<FontChoice, string> = { system: "System UI (default)", humanist: "Humanist sans", serif: "Serif (book-like)", rounded: "Rounded", mono: "Monospace" };

export function defaultDesign(): DesignConfig {
	return {
		title: "My Learning Library", description: "Study notes, PDFs and recordings, available offline.", logoPath: "",
		theme: "system", preset: "academic", accent: "#4f46e5", heroLayout: "split", cardStyle: "elevated", font: "system", navStyle: "solid", radius: 14,
		showBreadcrumb: true, showCourseNav: true, footerText: "",
	};
}

export function defaultOptions(): ExportOptions {
	return { mode: "site", embed: true, includePdf: true, includeAudio: true, includeVideo: true, includeOther: true, largeFileMB: 50, searchChars: 30000 };
}

export function applyPreset(d: DesignConfig, id: string): DesignConfig {
	const p = PRESETS.find((x) => x.id === id);
	return p ? { ...d, ...p.design, preset: id } : d;
}

export function safeColor(c: string): string {
	return /^#[0-9a-f]{6}$/i.test(c) ? c : "#4f46e5";
}

export function designCss(d: DesignConfig): string {
	const r = Math.max(0, Math.min(32, Math.round(Number(d.radius) || 0)));
	return `:root{--accent:${safeColor(d.accent)};--radius:${r}px;--font:${FONT_STACKS[d.font] ?? FONT_STACKS.system}}\n`;
}
