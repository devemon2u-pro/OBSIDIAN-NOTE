import type { AssetKind } from "./types";

export const PUA_OPEN = "\uE000";
export const PUA_CLOSE = "\uE001";
export const STASH_OPEN = "\uE002";
export const STASH_CLOSE = "\uE003";

export function esc(s: string): string {
	return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

/** Unicode-friendly slug for DOM ids / hashes (Bengali, Arabic, CJK ... keep working). */
export function slugU(s: string, fallback = "item"): string {
	const r = s
		.normalize("NFKC")
		.toLowerCase()
		.replace(/[^\p{L}\p{N}\p{M}]+/gu, "-")
		.replace(/^-+|-+$/g, "");
	return r.slice(0, 80) || fallback;
}

/** ASCII-only slug for file names. Falls back to a hash when nothing ASCII remains. */
export function fileSlug(s: string, fallbackPrefix = "item"): string {
	const r = s
		.normalize("NFKD")
		.replace(/[\u0300-\u036f]/g, "")
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, "-")
		.replace(/^-+|-+$/g, "")
		.slice(0, 48);
	return r || `${fallbackPrefix}-${hash(s)}`;
}

export function hash(s: string): string {
	let h = 0x811c9dc5;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 0x01000193) >>> 0;
	}
	return h.toString(36);
}

export function hueFrom(s: string): number {
	let h = 0;
	for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
	return h;
}

/** Normalise a vault path. Returns null when it tries to escape the root (path traversal). */
export function normPath(p: string): string | null {
	const out: string[] = [];
	for (const seg of p.replace(/\\/g, "/").split("/")) {
		if (seg === "" || seg === ".") continue;
		if (seg === "..") {
			if (!out.length) return null;
			out.pop();
		} else out.push(seg);
	}
	return out.join("/");
}

export function dirname(p: string): string {
	const i = p.lastIndexOf("/");
	return i < 0 ? "" : p.slice(0, i);
}

export function joinPath(...parts: string[]): string | null {
	return normPath(parts.filter(Boolean).join("/"));
}

/** Relative URL from a directory (output-relative) to a file (output-relative). */
export function relHref(fromDir: string, to: string): string {
	const a = fromDir ? fromDir.split("/") : [];
	const b = to.split("/");
	let i = 0;
	while (i < a.length && i < b.length - 1 && a[i] === b[i]) i++;
	const up = a.length - i;
	return "../".repeat(up) + b.slice(i).map(encodeURIComponent).join("/");
}

const MIME: Record<string, string> = {
	png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", svg: "image/svg+xml",
	bmp: "image/bmp", avif: "image/avif", ico: "image/x-icon",
	pdf: "application/pdf",
	mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", oga: "audio/ogg", m4a: "audio/mp4", flac: "audio/flac", aac: "audio/aac", opus: "audio/ogg", "3gp": "audio/3gpp",
	mp4: "video/mp4", webm: "video/webm", ogv: "video/ogg", mov: "video/quicktime", mkv: "video/x-matroska", m4v: "video/mp4",
};
export function mimeFor(ext: string): string {
	return MIME[ext.toLowerCase()] ?? "application/octet-stream";
}
export function kindFor(ext: string): AssetKind {
	const e = ext.toLowerCase();
	if (["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp", "avif", "ico"].includes(e)) return "image";
	if (e === "pdf") return "pdf";
	if (["mp3", "wav", "ogg", "oga", "m4a", "flac", "aac", "opus", "3gp"].includes(e)) return "audio";
	if (["mp4", "webm", "ogv", "mov", "mkv", "m4v"].includes(e)) return "video";
	return "other";
}

export function formatBytes(n: number): string {
	if (n < 1024) return `${n} B`;
	if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
	if (n < 1073741824) return `${(n / 1048576).toFixed(1)} MB`;
	return `${(n / 1073741824).toFixed(2)} GB`;
}

export const naturalCompare = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" }).compare;

export function htmlToText(html: string): string {
	return html
		.replace(/<(script|style)[\s\S]*?<\/\1>/gi, " ")
		.replace(/<(br|\/p|\/div|\/li|\/h[1-6]|\/tr)\s*\/?>/gi, "\n")
		.replace(/<[^>]+>/g, " ")
		.replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&")
		.replace(/[\uE000-\uE003]/g, "")
		.replace(/[ \t]+/g, " ")
		.replace(/\n\s*\n+/g, "\n")
		.trim();
}

/** JSON that is safe to place inside an inline <script>. */
export function safeJson(v: unknown): string {
	return JSON.stringify(v).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}

export function toBase64(data: Uint8Array): string {
	if (typeof Buffer !== "undefined") return Buffer.from(data.buffer, data.byteOffset, data.byteLength).toString("base64");
	let s = "";
	for (let i = 0; i < data.length; i += 0x8000) s += String.fromCharCode(...data.subarray(i, i + 0x8000));
	return btoa(s);
}

export function guardScript(js: string): string {
	return js.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
