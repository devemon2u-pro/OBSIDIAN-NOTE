import type { DesignConfig } from "./types";
import { RUNTIME_JS, VENDOR } from "./vendor";
import { designCss } from "./design";
import { homeBody, pageDoc, siteDataJs, type SiteModel } from "./layout";
import { PUA_CLOSE, PUA_OPEN, fileSlug, guardScript, hash, hueFrom } from "./util";

export interface PreviewCourse { title: string; description: string; category: string; featured: boolean; icon: string; lessons: number; minutes: number }

/** Self-contained homepage used for the live preview inside Obsidian (links are disabled). */
export function previewHomeHtml(design: DesignConfig, courses: PreviewCourse[], logoDataUri: string | null): string {
	const model: SiteModel = {
		id: "preview-" + hash(design.title), title: design.title || "Learning Library", single: false, logoId: logoDataUri ? "preview" : null, generated: "",
		courses: courses.map((c, i) => ({
			slug: fileSlug(c.title, "course") + i, title: c.title, description: c.description || `${c.lessons} lessons`, category: c.category || "Courses", featured: c.featured, icon: c.icon, hue: hueFrom(c.title),
			path: `pages/${i}.html`, minutes: c.minutes, lessons: Array.from({ length: c.lessons }, (_v, k) => ({ s: "l" + k, t: "Lesson " + (k + 1), g: "" })),
		})),
	};
	const css = designCss(design) + VENDOR.siteCss;
	let body = homeBody(model, design);
	if (logoDataUri) body = body.split(`${PUA_OPEN}url:preview${PUA_CLOSE}`).join(logoDataUri.replace(/"/g, ""));
	const tail = `<script>${guardScript(siteDataJs(model))}</script><script>${guardScript(RUNTIME_JS)}</script><script>document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a");if(a&&!a.closest(".drawer")){e.preventDefault()}},true)</script>`;
	return pageDoc({ title: "Preview", description: "", design, siteId: model.id, root: "", assets: "", bodyClass: `nav-${design.navStyle}`, bodyAttrs: 'data-page="home"', body, head: `<style>${css}</style>`, tail });
}
