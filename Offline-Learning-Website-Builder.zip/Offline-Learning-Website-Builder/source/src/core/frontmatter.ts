export interface Parsed {
	data: Record<string, string | string[]>;
	body: string;
}

/** Tiny YAML-subset reader: `key: value`, `key: [a, b]`, and `- item` lists. Enough for title/description/category/tags. */
export function parseFrontmatter(text: string): Parsed {
	const m = /^\uFEFF?---[ \t]*\r?\n([\s\S]*?)\r?\n(?:---|\.\.\.)[ \t]*(?:\r?\n|$)/.exec(text);
	if (!m) return { data: {}, body: text };
	const data: Record<string, string | string[]> = {};
	let key = "";
	for (const raw of m[1].split(/\r?\n/)) {
		const kv = /^([A-Za-z0-9_-]+)\s*:\s*(.*)$/.exec(raw);
		if (kv) {
			key = kv[1].toLowerCase();
			const v = kv[2].trim();
			if (v.startsWith("[") && v.endsWith("]")) data[key] = v.slice(1, -1).split(",").map((s) => unq(s)).filter(Boolean);
			else if (v === "") data[key] = [];
			else data[key] = unq(v);
		} else if (/^\s*-\s+/.test(raw) && key) {
			const cur = data[key];
			const item = unq(raw.replace(/^\s*-\s+/, ""));
			data[key] = Array.isArray(cur) ? [...cur, item] : [item];
		}
	}
	return { data, body: text.slice(m[0].length) };
}

function unq(s: string): string {
	s = s.trim();
	if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1);
	return s;
}

export function fmString(v: string | string[] | undefined): string {
	if (Array.isArray(v)) return v.join(", ");
	return v ?? "";
}
