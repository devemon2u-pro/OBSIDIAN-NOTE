/** HTML templates for the exported pages. All dynamic strings pass through esc(). */
import type { CardStyle, DesignConfig } from "./types";
import { esc, hueFrom, safeJson } from "./util";
import { icon } from "./icons";
import { tok } from "./markdown";

export interface SiteLesson { s: string; t: string; g: string }
export interface SiteCourse {
	slug: string; title: string; description: string; category: string; featured: boolean; icon: string; hue: number;
	/** URL from the site root to the course page ('' when the page is the file itself). */
	path: string; minutes: number; lessons: SiteLesson[];
}
export interface SiteModel { id: string; title: string; courses: SiteCourse[]; single: boolean; logoId: string | null; generated: string }

export function earlyThemeScript(siteId: string, theme: string): string {
	const key = JSON.stringify(`olwb:${siteId}:theme`);
	return `<script>(function(){var d=document.documentElement,m=${JSON.stringify(theme)};try{var v=localStorage.getItem(${key});if(v)m=JSON.parse(v)}catch(e){try{if(String(window.name).indexOf("OLWB")===0){var o=JSON.parse(window.name.slice(4));if(o[${key}])m=JSON.parse(o[${key}])}}catch(e2){}}d.classList.remove("no-js");d.classList.add("js");d.setAttribute("data-default-theme",${JSON.stringify(theme)});d.setAttribute("data-theme",m==="dark"||(m!=="light"&&window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light")})();</script>`;
}

export interface DocOpts {
	title: string; description: string; design: DesignConfig; siteId: string; root: string; assets: string;
	bodyClass: string; bodyAttrs: string; body: string; head: string; tail: string;
}

export function pageDoc(o: DocOpts): string {
	return `<!doctype html>
<html lang="en" class="no-js" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(o.title)}</title>
<meta name="description" content="${esc(o.description)}">
<meta name="olwb-root" content="${esc(o.root)}">
<meta name="olwb-assets" content="${esc(o.assets)}">
<meta name="generator" content="Offline Learning Website Builder">
${earlyThemeScript(o.siteId, o.design.theme)}
${o.head}
</head>
<body class="${esc(o.bodyClass)}" ${o.bodyAttrs}>
<noscript><div class="ns">JavaScript is turned off. Reading works, but search, the PDF viewer, media players, themes and progress tracking need JavaScript.</div></noscript>
<div class="readbar" aria-hidden="true"></div>
${o.body}
${o.tail}
</body>
</html>`;
}

function themeSwitch(): string {
	const b = (m: string, ic: string, label: string) => `<button type="button" data-theme-set="${m}" aria-pressed="false" title="${label}" aria-label="${label}">${icon(ic, 15)}</button>`;
	return `<div class="theme-switch" role="group" aria-label="Colour theme">${b("light", "sun", "Light theme")}${b("dark", "moon", "Dark theme")}${b("system", "monitor", "Match system theme")}</div>`;
}

export function navHtml(site: SiteModel, design: DesignConfig, ctx: { root: string; current: string | null; sidebarToggle: boolean }): string {
	const href = (c: SiteCourse) => ctx.root + encodeURI(c.path);
	const brandInner = (site.logoId ? `<img src="${tok("url", site.logoId)}" alt="">` : `<span class="brand-mark">${esc((site.title.trim()[0] ?? "L").toUpperCase())}</span>`) + `<span>${esc(site.title)}</span>`;
	const brand = site.single ? `<span class="brand">${brandInner}</span>` : `<a class="brand" href="${ctx.root}index.html">${brandInner}</a>`;
	let links = "";
	if (!site.single) {
		const cats = [...new Set(site.courses.map((c) => c.category))];
		const panel = cats.map((cat) => `<h4>${esc(cat)}</h4>` + site.courses.filter((c) => c.category === cat).map((c) => `<a href="${href(c)}"${c.slug === ctx.current ? ' class="current"' : ""}>${esc(c.title)}</a>`).join("")).join("");
		links = `<nav class="nav-links" aria-label="Main"><a href="${ctx.root}index.html">${icon("home", 16)} Home</a><details class="menu"><summary>${icon("grid", 16)} Courses ${icon("down", 14)}</summary><div class="menu-panel">${panel}</div></details></nav>`;
	}
	let prevNext = "";
	if (!site.single && design.showCourseNav && ctx.current) {
		const i = site.courses.findIndex((c) => c.slug === ctx.current);
		const p = site.courses[i - 1], n = site.courses[i + 1];
		prevNext = `<span class="nav-pc">${p ? `<a class="btn" href="${href(p)}" title="Previous course: ${esc(p.title)}">${icon("left", 15)} Prev course</a>` : ""} ${n ? `<a class="btn" href="${href(n)}" title="Next course: ${esc(n.title)}">Next course ${icon("right", 15)}</a>` : ""}</span>`;
	}
	return `<header class="topnav"><div class="nav-inner">
${ctx.sidebarToggle ? `<button class="icon-btn mobile-only" data-act="lessons" aria-label="Lessons">${icon("menu")}</button>` : ""}
${brand}${links}<div class="nav-spacer"></div>${prevNext}
<button class="icon-btn" data-act="search" title="Search (Ctrl+K or /)" aria-label="Search">${icon("search")}</button>
<button class="icon-btn" data-act="library" title="Bookmarks, recent and favourites" aria-label="Library">${icon("bookmark")}</button>
${themeSwitch()}
${site.single ? "" : `<button class="icon-btn mobile-only" data-act="nav" aria-label="Menu">${icon("grid")}</button>`}
</div></header>`;
}

export function footerHtml(design: DesignConfig): string {
	return `<footer class="footer">${design.footerText ? esc(design.footerText) + " · " : ""}Works offline · Built with Offline Learning Website Builder</footer>`;
}

export function crumbs(items: { label: string; href?: string; id?: string }[]): string {
	return `<div class="crumbs" aria-label="Breadcrumb">${items.map((it) => (it.href ? `<a href="${it.href}">${esc(it.label)}</a>` : `<span${it.id ? ` id="${it.id}"` : ""}>${esc(it.label)}</span>`)).join('<span class="sep">›</span>')}</div>`;
}

const CARD_CLASS: Record<CardStyle, string> = { elevated: "cards-elevated", outlined: "cards-outlined", flat: "cards-flat", cover: "cards-cover" };

export function cardHtml(c: SiteCourse, root: string): string {
	const label = c.icon || c.title.trim().slice(0, 1).toUpperCase();
	return `<article class="card" data-slug="${esc(c.slug)}" data-category="${esc(c.category)}" data-title="${esc(c.title)}" data-desc="${esc(c.description)}">
<a class="card-link" href="${root}${encodeURI(c.path)}"><div class="card-cover" style="--h:${c.hue}"><span class="card-cat">${esc(c.category)}</span><span class="card-icon" aria-hidden="true">${esc(label)}</span></div>
<div class="card-body"><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><div class="progress" aria-hidden="true"><span></span></div><div class="card-meta"><span>${c.lessons.length} lesson${c.lessons.length === 1 ? "" : "s"} · ~${Math.max(1, c.minutes)} min</span><span class="pct"></span></div></div></a>
<button type="button" class="fav" data-fav="${esc(c.slug)}" aria-label="Favourite: ${esc(c.title)}" aria-pressed="false">${icon("star", 18)}</button></article>`;
}

export function homeBody(site: SiteModel, design: DesignConfig): string {
	const root = "";
	const cats = [...new Set(site.courses.map((c) => c.category))];
	const lessons = site.courses.reduce((n, c) => n + c.lessons.length, 0);
	const mins = site.courses.reduce((n, c) => n + c.minutes, 0);
	const featured = site.courses.filter((c) => c.featured);
	const grid = (cs: SiteCourse[], id?: string) => `<div class="grid ${CARD_CLASS[design.cardStyle]}"${id ? ` id="${id}"` : ""}>${cs.map((c) => cardHtml(c, root)).join("")}</div>`;
	return `${navHtml(site, design, { root, current: null, sidebarToggle: false })}
<main>
<section class="hero hero-${design.heroLayout}"><div class="hero-inner"><div class="hero-text">
<span class="eyebrow">Offline learning</span><h1>${esc(site.title)}</h1><p class="lead">${esc(design.description)}</p>
<div class="hero-search"><input id="olwb-hero-search" type="search" placeholder="Filter courses… (Enter searches every lesson)" aria-label="Filter courses"><button class="btn primary" id="olwb-hero-search-btn" type="button">${icon("search", 16)} Search</button></div>
<div class="stats"><div><b>${site.courses.length}</b>courses</div><div><b>${lessons}</b>lessons</div><div><b>${mins >= 90 ? Math.round(mins / 60) + " h" : mins + " min"}</b>of reading</div></div>
</div><div class="hero-art" aria-hidden="true"><i></i><i></i><i></i></div></div></section>
<div class="wrap" id="olwb-continue" hidden><h2>Continue learning</h2><div class="grid ${CARD_CLASS[design.cardStyle]}"></div></div>
<div class="wrap" id="olwb-favs" hidden><h2>Favourites</h2><div class="grid ${CARD_CLASS[design.cardStyle]}"></div></div>
${featured.length ? `<div class="wrap"><h2>Featured courses</h2>${grid(featured)}</div>` : ""}
<div class="wrap"><div class="sec-head"><h2>All courses</h2><div class="chips"><button class="chip on" type="button" data-cat="">All</button>${cats.map((c) => `<button class="chip" type="button" data-cat="${esc(c)}">${esc(c)}</button>`).join("")}</div></div>
${grid(site.courses, "olwb-all-courses")}<p class="empty" id="olwb-no-match" hidden>No course matches your filter.</p></div>
</main>${footerHtml(design)}`;
}

export function courseBody(site: SiteModel, c: SiteCourse, lessonsHtml: { s: string; t: string; html: string }[], design: DesignConfig, estimate: string): string {
	const root = site.single ? "" : "../";
	const multi = c.lessons.length > 1;
	let side = "";
	if (multi) {
		let lastGroup = "";
		const items = c.lessons.map((l) => {
			let g = "";
			if (l.g && l.g !== lastGroup) g = `<div class="lesson-group">${esc(l.g)}</div>`;
			lastGroup = l.g;
			return `${g}<a class="lesson-link" href="#${esc(l.s)}" data-lesson="${esc(l.s)}"><span class="check">${icon("check", 10)}</span><span>${esc(l.t)}</span></a>`;
		});
		side = `<aside class="sidebar" id="olwb-sidebar" aria-label="Lessons"><span class="side-title">${esc(c.title)}</span><div class="side-progress"><div class="progress"><span id="olwb-side-bar"></span></div><span id="olwb-side-pct">0%</span></div><nav class="lesson-list">${items.join("")}</nav></aside>`;
	}
	const arts = lessonsHtml.map((l, i) => {
		const p = lessonsHtml[i - 1], n = lessonsHtml[i + 1];
		const foot = multi ? `<footer class="lesson-foot">${p ? `<a class="prev" href="#${esc(p.s)}"><small>← Previous</small>${esc(p.t)}</a>` : "<span></span>"}${n ? `<a class="next" href="#${esc(n.s)}"><small>Next →</small>${esc(n.t)}</a>` : ""}</footer>` : "";
		return `<article class="lesson" id="${esc(l.s)}" data-title="${esc(l.t)}"><header class="lesson-head"><h1 class="lesson-title">${esc(l.t)}</h1><div class="lesson-actions"><button class="btn" type="button" data-act="bookmark">${icon("bookmark", 14)} Bookmark</button><button class="btn" type="button" data-act="done">${icon("check", 14)} Mark complete</button><button class="btn" type="button" data-act="focus" title="Hide navigation and read in focus">${icon("eye", 14)} Focus</button><button class="btn" type="button" data-act="print">${icon("printer", 14)} Print</button></div></header><div class="prose">${l.html}</div>${foot}</article>`;
	}).join("\n");
	const crumbItems: { label: string; href?: string; id?: string }[] = [];
	if (!site.single) crumbItems.push({ label: "Home", href: root + "index.html" }, { label: c.category });
	crumbItems.push({ label: c.title });
	if (multi) crumbItems.push({ label: "", id: "olwb-crumb-lesson" });
	return `${navHtml(site, design, { root, current: c.slug, sidebarToggle: multi })}
${design.showBreadcrumb ? crumbs(crumbItems) : ""}
<button class="btn focus-exit" type="button" data-act="unfocus">Exit focus (Esc)</button>
<div class="layout${multi ? "" : " no-sidebar"}">${side}<main class="content"><div class="course-header"><span class="pill">${esc(c.category)}</span><h1>${esc(c.title)}</h1>${c.description ? `<p>${esc(c.description)}</p>` : ""}<div class="meta">${c.lessons.length} lesson${c.lessons.length === 1 ? "" : "s"} · ~${Math.max(1, c.minutes)} min read${estimate ? " · " + estimate : ""}</div></div>${arts}</main><aside class="toc" id="olwb-toc" aria-label="On this page"></aside></div>
${footerHtml(design)}`;
}

export function readmeBody(site: SiteModel, design: DesignConfig, warnings: string[], size: string): string {
	return `${navHtml(site, design, { root: "", current: null, sidebarToggle: false })}
<main class="wrap prose" style="max-width:820px">
<h1>How to use this website</h1>
<p>This is a fully offline learning website generated from Obsidian notes on ${esc(site.generated)}. No internet connection, server or account is needed.</p>
<h2>Opening it</h2><ol><li>Keep the whole folder together (index.html, <code>pages</code>, <code>assets</code>).</li><li>Double-click <code>index.html</code>. A modern browser (Chrome, Edge, Firefox, Safari) is recommended.</li><li>You can copy the folder to a USB drive or another computer; links are relative.</li></ol>
<h2>Tips</h2><ul><li>Press <kbd>Ctrl</kbd>+<kbd>K</kbd> or <kbd>/</kbd> to search every lesson.</li><li>Bookmarks, favourites and progress are saved in your browser. Some browsers restrict storage for local files; then they only last for the current tab.</li><li>PDFs open in a built-in viewer; the download button saves the original file.</li><li>Print or Focus mode are available on every lesson.</li></ul>
<h2>This export</h2><p>${site.courses.length} courses · total size about ${esc(size)}.</p>
${site.courses.map((c) => `<p><a href="${encodeURI(c.path)}">${esc(c.title)}</a> — ${c.lessons.length} lessons</p>`).join("")}
${warnings.length ? `<h2>Warnings from the export</h2><ul>${warnings.slice(0, 80).map((w) => `<li>${esc(w)}</li>`).join("")}</ul>` : ""}
</main>${footerHtml(design)}`;
}

export function siteDataJs(site: SiteModel): string {
	const data = { id: site.id, title: site.title, single: site.single, courses: site.courses.map((c) => ({ slug: c.slug, title: c.title, description: c.description, category: c.category, path: c.path, lessons: c.lessons })) };
	return `window.__OLWB_SITE=${safeJson(data)};`;
}

export { hueFrom };
