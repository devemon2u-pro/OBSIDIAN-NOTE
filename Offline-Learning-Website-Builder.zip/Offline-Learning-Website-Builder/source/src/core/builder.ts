/**
 * Plans and writes an offline learning website.
 *   planSite()  - reads notes, converts them, collects attachments (no files are written; used for preview/estimates)
 *   writePlan() - writes pages, assets and libraries to an OutputWriter
 */
import type { AssetInfo, CourseConfig, CoursePlan, DesignConfig, ExportOptions, LessonPlan, OutputWriter, PlannedPage, ProgressFn, SitePlan, VFile, VaultAdapter } from "./types";
import { parseFrontmatter, fmString } from "./frontmatter";
import { newState, renderMarkdown, tok, type RenderEnv } from "./markdown";
import { designCss } from "./design";
import { RUNTIME_JS, VENDOR } from "./vendor";
import { courseBody, footerHtml, homeBody, pageDoc, readmeBody, siteDataJs, type SiteCourse, type SiteModel } from "./layout";
import { PUA_CLOSE, PUA_OPEN, dirname, fileSlug, formatBytes, guardScript, hash, htmlToText, hueFrom, kindFor, mimeFor, naturalCompare, relHref, safeJson, slugU, toBase64 } from "./util";

const MB = 1048576;
const MAX_EMBED_BYTES = 300 * MB;
const KIND_DIR = { image: "images", pdf: "pdf", audio: "audio", video: "video", other: "files" } as const;
const ASSET_MARK = `${PUA_OPEN}assets${PUA_CLOSE}`;

export interface PlanInput {
	adapter: VaultAdapter;
	courses: CourseConfig[];
	design: DesignConfig;
	options: ExportOptions;
	onProgress?: ProgressFn;
}

export async function planSite(input: PlanInput): Promise<SitePlan> {
	const { adapter, design, options } = input;
	const progress: ProgressFn = input.onProgress ?? (() => undefined);
	const warnings: string[] = [];
	const warned = new Set<string>();
	const warn = (m: string) => { if (!warned.has(m)) { warned.add(m); warnings.push(m); } };
	const single = options.mode === "single";
	const embedded = single && options.embed;

	let courses = input.courses.filter((c) => c.path);
	if (!courses.length) throw new Error("No courses selected. Add at least one folder or note first.");
	if (single) courses = courses.slice(0, 1);

	// ---- unique course slugs
	const slugs = new Set<string>();
	const slugOf = new Map<CourseConfig, string>();
	for (const c of courses) {
		let s = fileSlug(c.title || c.path, "course"), k = 2;
		const base = s;
		while (slugs.has(s)) s = `${base}-${k++}`;
		slugs.add(s);
		slugOf.set(c, s);
	}
	const assetsRoot = embedded ? "" : single ? `${slugOf.get(courses[0])}_assets` : "assets";

	// ---- asset registry
	const assetMap = new Map<string, AssetInfo>();
	const registerAsset = (f: VFile, force = false): AssetInfo | null => {
		const have = assetMap.get(f.path);
		if (have) return have;
		const kind = kindFor(f.extension);
		if (!force && ((kind === "pdf" && !options.includePdf) || (kind === "audio" && !options.includeAudio) || (kind === "video" && !options.includeVideo) || (kind === "other" && !options.includeOther))) return null;
		if (embedded && f.size > MAX_EMBED_BYTES) {
			warn(`"${f.name}" is ${formatBytes(f.size)} and is too large to embed in one HTML file. It was skipped. Export with a separate assets folder instead.`);
			return null;
		}
		if (f.size > options.largeFileMB * MB) {
			warn(embedded
				? `"${f.name}" is ${formatBytes(f.size)}. Embedding it (base64 adds ~33%) makes a very large HTML file that some browsers may fail to open. Consider exporting with a separate assets folder.`
				: `"${f.name}" is ${formatBytes(f.size)}. This is a large file; copying it will take space and time.`);
		}
		const id = "a" + hash(f.path);
		const ext = f.extension.toLowerCase().replace(/[^a-z0-9]/g, "") || "bin";
		const info: AssetInfo = { id, path: f.path, name: f.name, ext, kind, mime: mimeFor(ext), size: f.size, outRel: `${assetsRoot}/${KIND_DIR[kind]}/${fileSlug(f.basename, "file")}-${hash(f.path).slice(0, 5)}.${ext}` };
		assetMap.set(f.path, info);
		return info;
	};

	// ---- lessons per course
	interface Pre { cfg: CourseConfig; slug: string; lessons: { file: VFile; slug: string; group: string }[] }
	const pre: Pre[] = [];
	const noteMap = new Map<string, { course: string; lesson: string }>();
	for (const cfg of courses) {
		const slug = slugOf.get(cfg)!;
		let files: VFile[] = [];
		let base = dirname(cfg.path);
		if (cfg.kind === "note") {
			const f = adapter.getFile(cfg.path);
			if (f) files = [f]; else warn(`Note not found: ${cfg.path}`);
		} else {
			files = adapter.listNotes(cfg.path);
			base = cfg.path;
			const folderName = cfg.path.split("/").pop() ?? "";
			const rank = (f: VFile) => (dirname(f.path) === cfg.path && [folderName.toLowerCase(), "index", "readme", "home", "overview"].includes(f.basename.toLowerCase()) ? 0 : 1);
			files.sort((a, b) => rank(a) - rank(b) || naturalCompare(a.path, b.path));
		}
		if (!files.length) { warn(`Course "${cfg.title}" has no notes and was skipped.`); continue; }
		const used = new Set<string>();
		const lessons = files.map((file) => {
			const rel = cfg.kind === "note" ? file.basename : file.path.slice(base.length ? base.length + 1 : 0).replace(/\.md$/i, "");
			let s = slugU(rel.replace(/\//g, "-"), "lesson"), k = 2;
			const b0 = s;
			while (used.has(s)) s = `${b0}-${k++}`;
			used.add(s);
			noteMap.set(file.path, { course: slug, lesson: s });
			const group = cfg.kind === "note" ? "" : dirname(rel).replace(/\//g, " / ");
			return { file, slug: s, group };
		});
		pre.push({ cfg, slug, lessons });
	}
	if (!pre.length) throw new Error("None of the selected folders or notes contain any Markdown notes.");

	// ---- convert
	const total = pre.reduce((n, p) => n + p.lessons.length, 0);
	let done = 0, words = 0;
	const plans: CoursePlan[] = [];
	for (const p of pre) {
		const needs = { math: false, pdf: false };
		const lessonPlans: LessonPlan[] = [];
		const env: RenderEnv = {
			readNote: (f) => adapter.readText(f.path),
			resolveLink: (l, src) => adapter.resolveLink(l, src),
			warn,
			registerAsset: (f) => registerAsset(f),
			noteHref: (f, heading, _from) => {
				const t = noteMap.get(f.path);
				if (!t) return null;
				const frag = heading ? `${t.lesson}--${slugU(heading, "section")}` : t.lesson;
				return t.course === p.slug ? `#${frag}` : single ? null : `${t.course}.html#${frag}`;
			},
		};
		let desc = p.cfg.description.trim();
		for (const l of p.lessons) {
			progress({ phase: "Converting notes", done, total, message: l.file.path });
			let title = l.file.basename, html = "", headings: LessonPlan["headings"] = [];
			try {
				const raw = await adapter.readText(l.file.path);
				const fm = parseFrontmatter(raw);
				title = fmString(fm.data.title) || l.file.basename;
				if (!desc && l === p.lessons[0] && fm.data.description) desc = fmString(fm.data.description);
				const st = newState(l.file.path, l.slug, title);
				html = await renderMarkdown(fm.body, st, env);
				headings = st.headings;
				needs.math ||= st.flags.math;
				needs.pdf ||= st.flags.pdf;
			} catch (e) {
				warn(`Could not convert ${l.file.path}: ${(e as Error).message}`);
				html = `<p class="unresolved">This note could not be converted (${(e as Error).message}).</p>`;
			}
			const text = htmlToText(html);
			const w = text ? text.split(/\s+/).length : 0;
			words += w;
			lessonPlans.push({ slug: l.slug, title, group: l.group, path: l.file.path, html, text: text.slice(0, options.searchChars), headings, words: w });
			done++;
		}
		const wc = lessonPlans.reduce((n, l) => n + l.words, 0);
		plans.push({ slug: p.slug, config: { ...p.cfg, description: desc || `${lessonPlans.length} lesson${lessonPlans.length === 1 ? "" : "s"}` }, lessons: lessonPlans, hue: hueFrom(p.cfg.title), needs, minutes: Math.max(1, Math.round(wc / 200)) });
	}

	// ---- logo
	let logo: AssetInfo | null = null;
	if (design.logoPath) {
		const lf = adapter.getFile(design.logoPath);
		if (lf && kindFor(lf.extension) === "image") logo = registerAsset(lf, true);
		else warn(`Logo file not found or not an image: ${design.logoPath}`);
	}

	// ---- site model + pages
	const siteId = hash(design.title || "site");
	const model: SiteModel = {
		id: siteId, title: design.title || "Learning Library", single, logoId: logo?.id ?? null, generated: new Date().toISOString().slice(0, 10),
		courses: plans.map<SiteCourse>((c) => ({
			slug: c.slug, title: c.config.title, description: c.config.description, category: c.config.category || "Courses", featured: c.config.featured, icon: c.config.icon, hue: c.hue,
			path: single ? "" : `pages/${c.slug}.html`, minutes: c.minutes, lessons: c.lessons.map((l) => ({ s: l.slug, t: l.title, g: l.group })),
		})),
	};
	const css = designCss(design) + VENDOR.siteCss;
	const dataJs = siteDataJs(model);
	const indexEntries = plans.flatMap((c) => c.lessons.map((l) => ({ c: c.slug, l: l.slug, t: l.title, h: l.headings.map((h) => h.text), x: l.text })));
	const indexJs = `window.__OLWB_INDEX=${safeJson(indexEntries)};`;
	const lib = (f: string) => `${assetsRoot}/libraries/${f}`;

	const resources = (pageDir: string, needs: { math: boolean; pdf: boolean }, withIndex: boolean) => {
		let head = "", tail = "";
		if (embedded) {
			head += `<style>${css.replace(/<\/style/gi, "<\\/style")}</style>`;
			if (needs.math) head += `<style>${VENDOR.katexCss}</style>`;
			tail += `<script>${guardScript(dataJs)}</script>`;
			if (withIndex) tail += `<script>${guardScript(indexJs)}</script>`;
			if (needs.math) tail += `<script>${guardScript(VENDOR.katexJs)}</script>`;
			tail += `<script>${guardScript(RUNTIME_JS)}</script>`;
			if (needs.pdf) tail += `<script type="text/plain" data-olwb-lib="pdfjs-lib">${toBase64(new TextEncoder().encode(VENDOR.pdfjsLib))}</script><script type="text/plain" data-olwb-lib="pdfjs-worker">${toBase64(new TextEncoder().encode(VENDOR.pdfWorker))}</script>`;
			tail += ASSET_MARK;
		} else {
			head += `<link rel="stylesheet" href="${relHref(pageDir, lib("site.css"))}">`;
			if (needs.math) head += `<link rel="stylesheet" href="${relHref(pageDir, lib("katex.css"))}">`;
			tail += `<script src="${relHref(pageDir, `${assetsRoot}/site-data.js`)}"></script>`;
			if (needs.math) tail += `<script src="${relHref(pageDir, lib("katex.min.js"))}"></script>`;
			tail += `<script src="${relHref(pageDir, lib("runtime.js"))}"></script>` + ASSET_MARK;
		}
		return { head, tail };
	};
	const assetsHref = (pageDir: string) => (embedded ? "" : relHref(pageDir, `${assetsRoot}/_`).slice(0, -1));

	const pages: PlannedPage[] = [];
	for (const c of plans) {
		const sc = model.courses.find((x) => x.slug === c.slug)!;
		const rel = single ? `${c.slug}.html` : `pages/${c.slug}.html`;
		const pageDir = dirname(rel);
		const r = resources(pageDir, c.needs, embedded);
		const body = courseBody(model, sc, c.lessons.map((l) => ({ s: l.slug, t: l.title, html: l.html })), design, "");
		pages.push({ rel, needs: c.needs, html: pageDoc({ title: `${c.config.title} · ${model.title}`, description: c.config.description, design, siteId, root: single ? "" : "../", assets: assetsHref(pageDir), bodyClass: `nav-${design.navStyle}`, bodyAttrs: `data-page="course" data-course="${c.slug}"`, body, head: r.head, tail: r.tail }) });
	}
	let entry = pages[0].rel;
	let estimated = 0;
	const assets = [...assetMap.values()];
	const assetBytes = assets.reduce((n, a) => n + a.size, 0);
	if (!single) {
		const needsAny = { math: false, pdf: false };
		const rh = resources("", needsAny, false);
		pages.unshift({ rel: "index.html", needs: needsAny, html: pageDoc({ title: model.title, description: design.description, design, siteId, root: "", assets: assetsHref(""), bodyClass: `nav-${design.navStyle}`, bodyAttrs: 'data-page="home"', body: homeBody(model, design), head: rh.head, tail: rh.tail }) });
		const size = formatBytes(assetBytes);
		pages.push({ rel: "README.html", needs: needsAny, html: pageDoc({ title: `README · ${model.title}`, description: "How to use this website", design, siteId, root: "", assets: assetsHref(""), bodyClass: `nav-${design.navStyle}`, bodyAttrs: 'data-page="readme"', body: readmeBody(model, design, warnings, size), head: rh.head, tail: rh.tail }) });
		entry = "index.html";
	}
	const anyPdf = plans.some((c) => c.needs.pdf), anyMath = plans.some((c) => c.needs.math);
	const htmlBytes = pages.reduce((n, p) => n + p.html.length, 0);
	if (embedded) estimated = htmlBytes + Math.ceil(assetBytes * 1.37) + (anyPdf ? 2.3 * MB : 0);
	else estimated = htmlBytes + assetBytes + assets.filter((a) => a.kind === "pdf").reduce((n, a) => n + Math.ceil(a.size * 1.37), 0) + css.length + RUNTIME_JS.length + indexJs.length + (anyPdf ? 2.3 * MB : 0) + (anyMath ? 0.64 * MB : 0);
	if (embedded && estimated > 150 * MB) warn(`The single HTML file will be about ${formatBytes(estimated)}. Browsers may be slow or fail to open files this large. Consider a separate assets folder.`);

	return {
		options, design, entry, pages, courses: plans, assets, logo, warnings, assetsRoot, estimatedBytes: Math.round(estimated),
		stats: { courses: plans.length, lessons: total, assets: assets.length, assetBytes, words },
		siteDataJs: dataJs, searchIndexJs: indexJs, cssText: css,
	};
}

/** Replace asset tokens, inline images and embedded files. */
async function finalizeHtml(page: PlannedPage, plan: SitePlan, adapter: VaultAdapter): Promise<string> {
	const embedded = plan.options.mode === "single" && plan.options.embed;
	const byId = new Map<string, AssetInfo>();
	for (const a of plan.assets) byId.set(a.id, a);
	const pageDir = dirname(page.rel);
	const re = new RegExp(`${PUA_OPEN}(url|pdfjs):([a-z0-9]+)${PUA_CLOSE}`, "g");
	const ids = new Set<string>();
	for (const m of page.html.matchAll(re)) ids.add(m[2]);
	const dataUris = new Map<string, string>();
	const blobs: string[] = [];
	if (embedded) {
		for (const id of ids) {
			const a = byId.get(id);
			if (!a) continue;
			const b64 = toBase64(await adapter.readBinary(a.path));
			if (a.kind === "image") dataUris.set(id, `data:${a.mime};base64,${b64}`);
			else blobs.push(`<script type="text/plain" data-olwb-asset="${a.id}" data-mime="${a.mime}">${b64}</script>`);
		}
	}
	let html = page.html.replace(re, (_m, kind: string, id: string) => {
		const a = byId.get(id);
		if (!a) return "";
		if (embedded) return kind === "pdfjs" ? "" : dataUris.get(id) ?? `olwb-asset:${id}`;
		return kind === "pdfjs" ? relHref(pageDir, a.outRel + ".js") : relHref(pageDir, a.outRel);
	});
	html = html.replace(ASSET_MARK, () => blobs.join(""));
	return html;
}

export interface WriteResult { files: number; bytes: number; entry: string }

export async function writePlan(plan: SitePlan, adapter: VaultAdapter, writer: OutputWriter, onProgress?: ProgressFn): Promise<WriteResult> {
	const progress: ProgressFn = onProgress ?? (() => undefined);
	const embedded = plan.options.mode === "single" && plan.options.embed;
	const site = plan.options.mode === "site";
	const written = new Set<string>();
	let bytes = 0;
	const wt = async (rel: string, text: string) => { await writer.writeText(rel, text); written.add(rel); bytes += text.length; };
	const wb = async (rel: string, data: Uint8Array) => { await writer.writeBinary(rel, data); written.add(rel); bytes += data.length; };
	const steps = plan.assets.length + plan.pages.length + 6;
	let n = 0;
	const tick = (message: string) => progress({ phase: "Writing files", done: n++, total: steps, message });

	if (!embedded) {
		for (const a of plan.assets) {
			tick(a.name);
			const data = await adapter.readBinary(a.path);
			await wb(a.outRel, data);
			if (a.kind === "pdf") await wt(`${a.outRel}.js`, `(window.__OLWB_PDF=window.__OLWB_PDF||{})[${JSON.stringify(a.id)}]=${JSON.stringify(toBase64(data))};`);
		}
		const lib = (f: string) => `${plan.assetsRoot}/libraries/${f}`;
		tick("Libraries");
		await wt(lib("site.css"), plan.cssText);
		await wt(lib("runtime.js"), RUNTIME_JS);
		await wt(`${plan.assetsRoot}/site-data.js`, plan.siteDataJs);
		await wt(`${plan.assetsRoot}/search-index.js`, plan.searchIndexJs);
		if (plan.courses.some((c) => c.needs.math)) { await wt(lib("katex.min.js"), VENDOR.katexJs); await wt(lib("katex.css"), VENDOR.katexCss); }
		if (plan.courses.some((c) => c.needs.pdf)) {
			await wt(lib("pdfjs-lib.js"), VENDOR.pdfjsLib);
			await wt(lib("pdfjs-worker.js"), `(window.__OLWB_LIBS=window.__OLWB_LIBS||{})["pdfjs-worker"]=${JSON.stringify(toBase64(new TextEncoder().encode(VENDOR.pdfWorker)))};`);
		}
	}
	for (const p of plan.pages) {
		tick(p.rel);
		await wt(p.rel, await finalizeHtml(p, plan, adapter));
	}
	if (site) {
		tick("Cleaning up old files");
		const MAN = ".olwb-manifest.json";
		try {
			const prev = await writer.readText(MAN);
			if (prev) for (const f of (JSON.parse(prev).files ?? []) as string[]) if (!written.has(f) && typeof f === "string") await writer.remove(f).catch(() => undefined);
		} catch { /* no usable previous manifest */ }
		await wt(MAN, JSON.stringify({ generator: "Offline Learning Website Builder", date: new Date().toISOString(), files: [...written] }, null, 1));
	}
	progress({ phase: "Done", done: steps, total: steps });
	void footerHtml;
	return { files: written.size, bytes, entry: plan.entry };
}
