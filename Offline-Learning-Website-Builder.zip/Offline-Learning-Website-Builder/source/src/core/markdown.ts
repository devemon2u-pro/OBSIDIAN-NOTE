/**
 * Obsidian-flavoured Markdown -> safe HTML.
 *
 * Security model: ALL text is HTML-escaped. Raw HTML from notes is never passed through, except a tiny
 * whitelist of attribute-less inline tags (<br>, <sub>, <sup>, <u>, <mark>, <kbd> ...). Links are only emitted for
 * http(s)/mailto/tel/#hash or vault files that were resolved by the VaultAdapter. Nothing from a note is ever executed.
 */
import type { AssetInfo, VFile } from "./types";
import { PUA_CLOSE, PUA_OPEN, STASH_CLOSE, STASH_OPEN, dirname, esc, htmlToText, joinPath, slugU } from "./util";

export interface RenderEnv {
	readNote(f: VFile): Promise<string>;
	resolveLink(linkpath: string, sourcePath: string): VFile | null;
	/** href for a note that is part of the export, or null if it is not exported. */
	noteHref(f: VFile, headingId: string | null, fromLesson: string): string | null;
	/** Register an attachment. Returns null if it is excluded by the export options. */
	registerAsset(f: VFile): AssetInfo | null;
	warn(msg: string): void;
}

export interface RenderState {
	sourcePath: string;
	lessonSlug: string;
	depth: number;
	chain: string[];
	headings: { level: number; text: string; id: string }[];
	used: Set<string>;
	flags: { math: boolean; pdf: boolean };
	noHeadings: boolean;
	titleToSkip: string | null;
}

export function newState(sourcePath: string, lessonSlug: string, title: string | null): RenderState {
	return { sourcePath, lessonSlug, depth: 0, chain: [sourcePath], headings: [], used: new Set(), flags: { math: false, pdf: false }, noHeadings: false, titleToSkip: title };
}

export const tok = (kind: "url" | "pdfjs", id: string): string => `${PUA_OPEN}${kind}:${id}${PUA_CLOSE}`;

const CALLOUT_ALIASES: Record<string, string> = {
	summary: "abstract", tldr: "abstract", hint: "tip", important: "tip", check: "success", done: "success", help: "question", faq: "question",
	caution: "warning", attention: "warning", fail: "failure", missing: "failure", error: "danger", cite: "quote",
};
const CALLOUT_ICON: Record<string, string> = {
	note: "✎", abstract: "☰", info: "ℹ", todo: "☑", tip: "💡", success: "✔", question: "?", warning: "⚠", failure: "✖", danger: "⚡", bug: "🐞", example: "▤", quote: "❝",
};

const LIST_RE = /^(\s*)([-*+]|\d{1,9}[.)])\s+(.*)$/;
const FENCE_RE = /^(\s*)(`{3,}|~{3,})\s*([^\s`]*)\s*.*$/;
const HR_RE = /^\s{0,3}([-*_])(?:\s*\1){2,}\s*$/;
const TABLE_DELIM = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;

export async function renderMarkdown(body: string, st: RenderState, env: RenderEnv): Promise<string> {
	let text = body.replace(/\r\n?/g, "\n").replace(/[\uE000-\uE003]/g, "");
	text = text.replace(/%%[\s\S]*?%%/g, "").replace(/<!--[\s\S]*?-->/g, "");
	const lines = text.split("\n").map((l) => l.replace(/^(\s*)\t+/, (m) => m.replace(/\t/g, "    ")));
	return blocks(lines, st, env);
}

async function blocks(lines: string[], st: RenderState, env: RenderEnv): Promise<string> {
	const out: string[] = [];
	let i = 0;
	const n = lines.length;
	while (i < n) {
		const line = lines[i];
		if (!line.trim()) { i++; continue; }

		// fenced code
		const fm = FENCE_RE.exec(line);
		if (fm) {
			const fence = fm[2];
			const lang = fm[3].toLowerCase();
			const buf: string[] = [];
			i++;
			while (i < n && !(lines[i].trim().startsWith(fence[0].repeat(fence.length)) && /^\s*(`+|~+)\s*$/.test(lines[i]))) {
				buf.push(lines[i].replace(new RegExp("^ {0," + fm[1].length + "}"), ""));
				i++;
			}
			i++;
			const code = buf.join("\n");
			if (lang === "math" || lang === "latex") out.push(mathBlock(code, st));
			else {
				const note = lang === "mermaid" ? `<div class="fallback-note">Mermaid diagrams are not rendered offline; showing the source.</div>` : "";
				out.push(`<div class="codeblock" data-lang="${esc(lang)}">${note}<pre><code>${esc(code)}</code></pre></div>`);
			}
			continue;
		}

		// display math $$ ... $$
		if (/^\s*\$\$/.test(line)) {
			let s = line.trim().slice(2);
			const buf: string[] = [];
			if (s.includes("$$")) {
				buf.push(s.slice(0, s.indexOf("$$")));
				i++;
			} else {
				if (s.trim()) buf.push(s);
				i++;
				while (i < n && !lines[i].includes("$$")) buf.push(lines[i++]);
				if (i < n) { buf.push(lines[i].slice(0, lines[i].indexOf("$$"))); i++; }
			}
			out.push(mathBlock(buf.join("\n"), st));
			continue;
		}

		// ATX heading
		const hm = /^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$/.exec(line);
		if (hm) {
			out.push(await heading(hm[1].length, hm[2], st, env));
			i++;
			continue;
		}

		if (HR_RE.test(line)) { out.push("<hr>"); i++; continue; }

		// blockquote / callout
		if (/^\s{0,3}>/.test(line)) {
			const buf: string[] = [];
			while (i < n && /^\s{0,3}>/.test(lines[i])) buf.push(lines[i++].replace(/^\s{0,3}> ?/, ""));
			out.push(await quote(buf, st, env));
			continue;
		}

		// table
		if (line.includes("|") && i + 1 < n && TABLE_DELIM.test(lines[i + 1]) && lines[i + 1].includes("-")) {
			const head = splitRow(line);
			const aligns = splitRow(lines[i + 1]).map((c) => (c.startsWith(":") && c.endsWith(":") ? "center" : c.endsWith(":") ? "right" : c.startsWith(":") ? "left" : ""));
			i += 2;
			const rows: string[][] = [];
			while (i < n && lines[i].trim() && lines[i].includes("|")) rows.push(splitRow(lines[i++]));
			const cell = async (t: string, tag: string, k: number) => `<${tag}${aligns[k] ? ` style="text-align:${aligns[k]}"` : ""}>${await inline(t, st, env)}</${tag}>`;
			let h = "<div class=\"table-wrap\"><table><thead><tr>";
			for (let k = 0; k < head.length; k++) h += await cell(head[k], "th", k);
			h += "</tr></thead><tbody>";
			for (const r of rows) {
				h += "<tr>";
				for (let k = 0; k < head.length; k++) h += await cell(r[k] ?? "", "td", k);
				h += "</tr>";
			}
			out.push(h + "</tbody></table></div>");
			continue;
		}

		// list
		if (LIST_RE.test(line)) {
			const block: string[] = [];
			while (i < n) {
				const l = lines[i];
				if (!l.trim()) {
					const nx = lines.slice(i + 1).find((x) => x.trim());
					if (nx !== undefined && (LIST_RE.test(nx) || /^\s{2,}\S/.test(nx)) && i + 1 < n && lines[i + 1].trim()) { block.push(l); i++; continue; }
					break;
				}
				if (LIST_RE.test(l) || /^\s+\S/.test(l)) { block.push(l); i++; continue; }
				break;
			}
			out.push(await list(block, st, env));
			continue;
		}

		// paragraph (+ setext headings)
		const buf: string[] = [line];
		i++;
		let setext = 0;
		while (i < n && lines[i].trim()) {
			const l = lines[i];
			const su = /^\s{0,3}(=+|-+)\s*$/.exec(l);
			if (su && buf.length) { setext = su[1][0] === "=" ? 1 : 2; i++; break; }
			if (FENCE_RE.test(l) || /^\s{0,3}#{1,6}\s/.test(l) || HR_RE.test(l) || /^\s{0,3}>/.test(l) || LIST_RE.test(l) || /^\s*\$\$/.test(l)) break;
			if (l.includes("|") && i + 1 < n && TABLE_DELIM.test(lines[i + 1])) break;
			buf.push(l);
			i++;
		}
		if (setext) { out.push(await heading(setext, buf.join(" "), st, env)); continue; }
		const html = (await inline(buf.join("\n"), st, env)).replace(/\n/g, "<br>");
		out.push(buf.length === 1 && /^<(div|figure|details)[\s>]/.test(html) ? html : `<p>${html}</p>`);
	}
	return out.join("\n");
}

function mathBlock(tex: string, st: RenderState): string {
	st.flags.math = true;
	const t = tex.trim();
	return `<div class="math math-display" data-tex="${esc(t)}"><code>${esc(t)}</code></div>`;
}

async function heading(level: number, raw: string, st: RenderState, env: RenderEnv): Promise<string> {
	const html = await inline(raw, st, env);
	const plain = htmlToText(html);
	if (st.noHeadings) return `<h4 class="embed-h">${html}</h4>`;
	if (st.titleToSkip !== null) {
		const skip = st.titleToSkip;
		st.titleToSkip = null;
		if (level === 1 && plain.trim().toLowerCase() === skip.trim().toLowerCase()) return "";
	}
	let id = `${st.lessonSlug}--${slugU(plain, "section")}`;
	let k = 2;
	while (st.used.has(id)) id = `${st.lessonSlug}--${slugU(plain, "section")}-${k++}`;
	st.used.add(id);
	st.headings.push({ level, text: plain, id });
	return `<h${level} id="${esc(id)}">${html}<a class="anchor" href="#${esc(id)}" aria-label="Link to this heading">#</a></h${level}>`;
}

async function quote(buf: string[], st: RenderState, env: RenderEnv): Promise<string> {
	const m = /^\[!([\w-]+)\]([+-]?)[ \t]*(.*)$/.exec(buf[0] ?? "");
	if (!m) return `<blockquote>${await blocks(buf, st, env)}</blockquote>`;
	let type = m[1].toLowerCase();
	type = CALLOUT_ALIASES[type] ?? type;
	if (!CALLOUT_ICON[type]) type = "note";
	const titleRaw = m[3].trim() || m[1].charAt(0).toUpperCase() + m[1].slice(1).toLowerCase();
	const title = await inline(titleRaw, st, env);
	const content = await blocks(buf.slice(1), st, env);
	const head = `<span class="callout-icon" aria-hidden="true">${CALLOUT_ICON[type]}</span><span class="callout-title-inner">${title}</span>`;
	if (m[2]) return `<details class="callout is-foldable" data-callout="${type}"${m[2] === "+" ? " open" : ""}><summary class="callout-title">${head}</summary><div class="callout-content">${content}</div></details>`;
	return `<div class="callout" data-callout="${type}"><div class="callout-title">${head}</div><div class="callout-content">${content}</div></div>`;
}

function splitRow(line: string): string[] {
	let s = line.trim();
	if (s.startsWith("|")) s = s.slice(1);
	if (s.endsWith("|") && !s.endsWith("\\|")) s = s.slice(0, -1);
	const cells: string[] = [];
	let cur = "";
	let code = false;
	let wiki = 0;
	for (let i = 0; i < s.length; i++) {
		const c = s[i];
		if (c === "\\" && s[i + 1] === "|") { cur += wiki ? "|" : "\\|"; i++; continue; }
		if (c === "`") code = !code;
		if (c === "[" && s[i + 1] === "[") { wiki++; cur += "[["; i++; continue; }
		if (c === "]" && s[i + 1] === "]" && wiki) { wiki--; cur += "]]"; i++; continue; }
		if (c === "|" && !code && !wiki) { cells.push(cur.trim()); cur = ""; continue; }
		cur += c;
	}
	cells.push(cur.trim());
	return cells;
}

async function list(block: string[], st: RenderState, env: RenderEnv): Promise<string> {
	const first = LIST_RE.exec(block.find((l) => LIST_RE.test(l)) ?? "");
	if (!first) return "";
	const base = first[1].length;
	const ordered = /\d/.test(first[2]);
	const startNum = ordered ? parseInt(first[2], 10) : 1;
	const items: { text: string[]; kids: string[] }[] = [];
	for (const l of block) {
		const m = LIST_RE.exec(l);
		if (m && m[1].length <= base) items.push({ text: [m[3]], kids: [] });
		else if (items.length && l.trim()) {
			const cur = items[items.length - 1];
			if (LIST_RE.test(l) || cur.kids.length) cur.kids.push(l);
			else cur.text.push(l.trim());
		}
	}
	let html = ordered ? `<ol${startNum !== 1 ? ` start="${startNum}"` : ""}>` : "<ul>";
	for (const it of items) {
		let t = it.text.join("\n");
		let cls = "";
		let box = "";
		const tm = /^\[( |x|X)\]\s+/.exec(t);
		if (tm) {
			t = t.slice(tm[0].length);
			cls = ' class="task"';
			box = `<input type="checkbox" disabled${tm[1] !== " " ? " checked" : ""}> `;
		}
		const inner = (await inline(t, st, env)).replace(/\n/g, "<br>");
		const kids = it.kids.length ? await list(it.kids, st, env) : "";
		html += `<li${cls}>${box}${inner}${kids}</li>`;
	}
	return html + (ordered ? "</ol>" : "</ul>");
}

// ---------------------------------------------------------------- inline

async function replaceAsync(s: string, re: RegExp, fn: (m: RegExpExecArray) => Promise<string>): Promise<string> {
	const parts: string[] = [];
	let last = 0;
	re.lastIndex = 0;
	let m: RegExpExecArray | null;
	while ((m = re.exec(s))) {
		parts.push(s.slice(last, m.index), await fn(m));
		last = m.index + m[0].length;
		if (m[0].length === 0) re.lastIndex++;
	}
	parts.push(s.slice(last));
	return parts.join("");
}

const SAFE_TAGS = "br|sub|sup|u|mark|kbd|b|i|em|strong|small|s|del|ins";

export async function inline(src: string, st: RenderState, env: RenderEnv, depth = 0): Promise<string> {
	const stash: string[] = [];
	const put = (h: string) => `${STASH_OPEN}${stash.push(h) - 1}${STASH_CLOSE}`;
	let s = src;

	s = s.replace(/(`+)([\s\S]*?[^`])\1(?!`)/g, (_m, _t, code: string) => put(`<code>${esc(code.trim())}</code>`));
	s = s.replace(/\\([\\`*_{}[\]()#+\-.!|~=$<>%^])/g, (_m, c: string) => put(esc(c)));
	s = s.replace(/(?<![\\$])\$(?![\s$])((?:[^$\n\\]|\\.)+?)(?<![\s\\])\$(?!\d)/g, (_m, tex: string) => {
		st.flags.math = true;
		return put(`<span class="math" data-tex="${esc(tex)}"><code>${esc(tex)}</code></span>`);
	});

	// embeds ![[...]]
	s = await replaceAsync(s, /!\[\[([^\]\n]+)\]\]/g, async (m) => put(await embed(m[1], st, env)));
	// wikilinks [[...]]
	s = await replaceAsync(s, /\[\[([^\]\n]+)\]\]/g, async (m) => put(await wikilink(m[1], st, env)));
	// markdown images
	s = await replaceAsync(s, /!\[([^\]\n]*)\]\((<[^>\n]+>|[^)\s]+)(?:\s+"[^"]*")?\)/g, async (m) => put(await mdImage(m[1], unangle(m[2]), st, env)));
	// markdown links
	s = await replaceAsync(s, /\[([^\]\n]+)\]\((<[^>\n]+>|[^)\s]+)(?:\s+"[^"]*")?\)/g, async (m) => {
		const text = depth < 2 ? await inline(m[1], st, env, depth + 1) : esc(m[1]);
		return put(await mdLink(text, unangle(m[2]), st, env));
	});
	// autolinks
	s = s.replace(/<(https?:\/\/[^>\s]+)>/g, (_m, u: string) => put(extLink(esc(u), u)));
	s = s.replace(/(?<![\w"=/])(https?:\/\/[^\s<>\uE000-\uE003]+[^\s<>.,;:!?)\]'"\uE000-\uE003])/g, (_m, u: string) => put(extLink(esc(u), u)));

	s = esc(s);
	s = s.replace(new RegExp(`&lt;(${SAFE_TAGS})\\s*/?&gt;`, "gi"), (_m, t: string) => `<${t.toLowerCase()}>`);
	s = s.replace(new RegExp(`&lt;/(${SAFE_TAGS.replace("br|", "")})\\s*&gt;`, "gi"), (_m, t: string) => `</${t.toLowerCase()}>`);

	s = s.replace(/\*\*\*(?=\S)([\s\S]+?)(?<=\S)\*\*\*/g, "<strong><em>$1</em></strong>");
	s = s.replace(/\*\*(?=\S)([\s\S]+?)(?<=\S)\*\*/g, "<strong>$1</strong>");
	s = s.replace(/(?<![\w])__(?=\S)([\s\S]+?)(?<=\S)__(?![\w])/g, "<strong>$1</strong>");
	s = s.replace(/(?<![*\w])\*(?=[^\s*])([\s\S]+?)(?<=[^\s*])\*(?![*\w])/g, "<em>$1</em>");
	s = s.replace(/(?<![\w])_(?=[^\s_])([\s\S]+?)(?<=[^\s_])_(?![\w])/g, "<em>$1</em>");
	s = s.replace(/~~(?=\S)([\s\S]+?)(?<=\S)~~/g, "<del>$1</del>");
	s = s.replace(/==(?=\S)([\s\S]+?)(?<=\S)==/g, "<mark>$1</mark>");
	s = s.replace(/(^|[\s>(])#([\p{L}\p{N}_/-]*\p{L}[\p{L}\p{N}_/-]*)/gu, (_m, p: string, t: string) => `${p}<span class="tag">#${t}</span>`);

	for (let k = 0; k < 3 && s.includes(STASH_OPEN); k++) s = s.replace(new RegExp(`${STASH_OPEN}(\\d+)${STASH_CLOSE}`, "g"), (_m, n: string) => stash[+n] ?? "");
	return s;
}

function unangle(u: string): string {
	return u.startsWith("<") ? u.slice(1, -1) : u;
}

function extLink(textHtml: string, url: string): string {
	const u = safeUrl(url);
	return u ? `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer" class="external">${textHtml}</a>` : `<span class="unresolved" title="Blocked unsafe link">${textHtml}</span>`;
}

/** Only http(s), mailto and tel are allowed to leave the page. */
export function safeUrl(u: string): string | null {
	const t = u.trim();
	return /^(https?:\/\/|mailto:|tel:)/i.test(t) ? t : null;
}

function unresolved(textHtml: string, why: string): string {
	return `<span class="unresolved" title="${esc(why)}">${textHtml}</span>`;
}

function parseTarget(raw: string): { link: string; heading: string | null; block: string | null } {
	const hi = raw.indexOf("#");
	if (hi < 0) return { link: raw.trim(), heading: null, block: null };
	const link = raw.slice(0, hi).trim();
	const frag = raw.slice(hi + 1).trim();
	return frag.startsWith("^") ? { link, heading: null, block: frag.slice(1) } : { link, heading: frag, block: null };
}

function headingHref(heading: string | null, lessonSlug: string): string | null {
	return heading ? `${lessonSlug}--${slugU(heading, "section")}` : null;
}

async function wikilink(inner: string, st: RenderState, env: RenderEnv): Promise<string> {
	const bar = inner.indexOf("|");
	const targetRaw = bar < 0 ? inner : inner.slice(0, bar);
	const alias = bar < 0 ? "" : inner.slice(bar + 1).trim();
	const t = parseTarget(targetRaw);
	if (!t.link) {
		const hid = headingHref(t.heading, st.lessonSlug);
		const label = esc(alias || t.heading || "link");
		return hid ? `<a href="#${esc(hid)}" class="internal">${label}</a>` : label;
	}
	const file = env.resolveLink(t.link, st.sourcePath);
	const defaultLabel = t.heading ? `${t.link} › ${t.heading}` : t.link;
	const label = esc(alias || defaultLabel);
	if (!file) return unresolved(label, "This note does not exist in the vault");
	if (file.extension.toLowerCase() === "md") {
		const href = env.noteHref(file, t.heading, st.lessonSlug);
		return href ? `<a href="${esc(href)}" class="internal">${label}</a>` : unresolved(label, "This note is not part of the export");
	}
	const a = env.registerAsset(file);
	if (!a) return unresolved(label, "This attachment type was excluded from the export");
	return `<a href="${tok("url", a.id)}" download="${esc(a.name)}" class="attachment-link">${label}</a>`;
}

function sizeAttrs(parts: string[]): { w: string; h: string; alt: string } {
	let w = "", h = "", alt = "";
	for (const p of parts) {
		const m = /^(\d+)(?:x(\d+))?$/.exec(p.trim());
		if (m) { w = m[1]; h = m[2] ?? ""; } else alt = p.trim();
	}
	return { w, h, alt };
}

function imgTag(a: AssetInfo, alt: string, w: string, h: string): string {
	const dim = `${w ? ` width="${w}"` : ""}${h ? ` height="${h}"` : ""}`;
	return `<img src="${tok("url", a.id)}" alt="${esc(alt)}"${dim} loading="lazy" class="zoomable">`;
}

function attachmentCard(a: AssetInfo, label: string): string {
	return `<div class="attachment"><span class="attachment-name">${esc(label)}</span><a class="btn" href="${tok("url", a.id)}" download="${esc(a.name)}">Download</a></div>`;
}

function assetBlock(a: AssetInfo, label: string, st: RenderState, page: string | null): string {
	if (a.kind === "image") return imgTag(a, label, "", "");
	if (a.kind === "pdf") {
		st.flags.pdf = true;
		return `<div class="olwb-pdf" data-id="${a.id}" data-src="${tok("url", a.id)}" data-js="${tok("pdfjs", a.id)}" data-name="${esc(a.name)}"${page ? ` data-page="${esc(page)}"` : ""}><div class="fallback-note">PDF: <a href="${tok("url", a.id)}" download="${esc(a.name)}">${esc(a.name)}</a> (JavaScript is needed to view it inline)</div></div>`;
	}
	if (a.kind === "audio") return `<div class="olwb-audio" data-src="${tok("url", a.id)}" data-name="${esc(a.name)}"><a href="${tok("url", a.id)}" download="${esc(a.name)}">${esc(a.name)}</a></div>`;
	if (a.kind === "video") return `<div class="olwb-video" data-src="${tok("url", a.id)}" data-name="${esc(a.name)}"><a href="${tok("url", a.id)}" download="${esc(a.name)}">${esc(a.name)}</a></div>`;
	return attachmentCard(a, label);
}

async function embed(inner: string, st: RenderState, env: RenderEnv): Promise<string> {
	const parts = inner.split("|");
	const t = parseTarget(parts[0]);
	const { w, h, alt } = sizeAttrs(parts.slice(1));
	const file = env.resolveLink(t.link, st.sourcePath);
	if (!file) {
		env.warn(`Missing embed "${t.link}" in ${st.sourcePath}`);
		return unresolved(`⚠ Missing embed: ${esc(t.link)}`, "File not found in the vault");
	}
	if (file.extension.toLowerCase() === "md") return transclude(file, t, st, env);
	const a = env.registerAsset(file);
	if (!a) return unresolved(`Attachment not included: ${esc(file.name)}`, "Excluded by export options");
	if (a.kind === "image") return imgTag(a, alt || file.basename, w, h);
	const page = a.kind === "pdf" ? (/page=(\d+)/.exec(t.heading ?? "")?.[1] ?? null) : null;
	return assetBlock(a, alt || file.name, st, page);
}

async function transclude(file: VFile, t: ReturnType<typeof parseTarget>, st: RenderState, env: RenderEnv): Promise<string> {
	if (st.depth >= 2 || st.chain.includes(file.path)) return unresolved(`↻ ${esc(file.basename)} (embedded note skipped to avoid a loop)`, "Embedded note nesting limit");
	let text = (await env.readNote(file)).replace(/\r\n?/g, "\n");
	text = text.replace(/^\uFEFF?---[ \t]*\n[\s\S]*?\n---[ \t]*(\n|$)/, "");
	if (t.heading) text = sectionOf(text, t.heading) ?? text;
	else if (t.block) text = blockOf(text, t.block) ?? text;
	const sub: RenderState = { ...st, sourcePath: file.path, depth: st.depth + 1, chain: [...st.chain, file.path], noHeadings: true, titleToSkip: null };
	const html = await renderMarkdown(text, sub, env);
	st.flags.math ||= sub.flags.math;
	st.flags.pdf ||= sub.flags.pdf;
	return `<div class="embed-note"><div class="embed-title">${esc(file.basename)}${t.heading ? " › " + esc(t.heading) : ""}</div>${html}</div>`;
}

function sectionOf(text: string, heading: string): string | null {
	const lines = text.split("\n");
	const want = slugU(heading);
	let start = -1, level = 0;
	for (let i = 0; i < lines.length; i++) {
		const m = /^(#{1,6})\s+(.*?)\s*#*\s*$/.exec(lines[i]);
		if (!m) continue;
		if (start < 0) { if (slugU(m[2]) === want) { start = i + 1; level = m[1].length; } }
		else if (m[1].length <= level) return lines.slice(start, i).join("\n");
	}
	return start >= 0 ? lines.slice(start).join("\n") : null;
}

function blockOf(text: string, id: string): string | null {
	const lines = text.split("\n");
	const idx = lines.findIndex((l) => l.trimEnd().endsWith("^" + id));
	if (idx < 0) return null;
	let a = idx, b = idx;
	while (a > 0 && lines[a - 1].trim()) a--;
	while (b < lines.length - 1 && lines[b + 1].trim()) b++;
	return lines.slice(a, b + 1).join("\n").replace(new RegExp("\\s*\\^" + id + "\\s*$", "m"), "");
}

async function mdImage(altRaw: string, url: string, st: RenderState, env: RenderEnv): Promise<string> {
	const parts = altRaw.split("|");
	const { w, h, alt } = sizeAttrs(parts.slice(1));
	const altText = parts[0].trim() || alt;
	if (/^data:image\/(png|jpe?g|gif|webp|svg\+xml);base64,[A-Za-z0-9+/=]+$/i.test(url)) return `<img src="${esc(url)}" alt="${esc(altText)}" loading="lazy" class="zoomable">`;
	if (/^https?:\/\//i.test(url)) {
		env.warn(`Remote image skipped (needs internet): ${url}`);
		return `<a class="remote-image" href="${esc(url)}" target="_blank" rel="noopener noreferrer">🖼 Remote image (not available offline): ${esc(altText || url)}</a>`;
	}
	const file = findRelative(url, st, env);
	if (!file) { env.warn(`Image not found "${url}" in ${st.sourcePath}`); return unresolved(`⚠ Missing image: ${esc(url)}`, "File not found in the vault"); }
	const a = env.registerAsset(file);
	if (!a) return unresolved(`Attachment not included: ${esc(file.name)}`, "Excluded by export options");
	return a.kind === "image" ? imgTag(a, altText || file.basename, w, h) : assetBlock(a, altText || file.name, st, null);
}

function findRelative(url: string, st: RenderState, env: RenderEnv): VFile | null {
	let p = url.split("#")[0];
	try { p = decodeURIComponent(p); } catch { /* keep raw */ }
	if (!p) return null;
	const direct = env.resolveLink(p, st.sourcePath);
	if (direct) return direct;
	const joined = joinPath(dirname(st.sourcePath), p);
	return joined ? env.resolveLink(joined, st.sourcePath) : null;
}

async function mdLink(textHtml: string, url: string, st: RenderState, env: RenderEnv): Promise<string> {
	if (url.startsWith("#")) return `<a href="#${esc(st.lessonSlug + "--" + slugU(decodeURIComponentSafe(url.slice(1))))}" class="internal">${textHtml}</a>`;
	if (/^[a-z][a-z0-9+.-]*:/i.test(url)) return extLink(textHtml, url);
	const file = findRelative(url, st, env);
	if (!file) return unresolved(textHtml, "Link target not found in the vault");
	if (file.extension.toLowerCase() === "md") {
		const frag = url.includes("#") ? decodeURIComponentSafe(url.slice(url.indexOf("#") + 1)) : null;
		const href = env.noteHref(file, frag, st.lessonSlug);
		return href ? `<a href="${esc(href)}" class="internal">${textHtml}</a>` : unresolved(textHtml, "This note is not part of the export");
	}
	const a = env.registerAsset(file);
	if (!a) return unresolved(textHtml, "This attachment type was excluded from the export");
	return `<a href="${tok("url", a.id)}" download="${esc(a.name)}" class="attachment-link">${textHtml}</a>`;
}

function decodeURIComponentSafe(s: string): string {
	try { return decodeURIComponent(s); } catch { return s; }
}

export { headingHref };
