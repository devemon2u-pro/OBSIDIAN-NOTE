/** Node-only helpers: a safe folder writer (used by the plugin) and a plain-folder vault adapter (used by tests). */
import * as fs from "fs";
import * as path from "path";
import type { OutputWriter, VFile, VaultAdapter } from "./types";
import { normPath } from "./util";

export class NodeWriter implements OutputWriter {
	private base: string;
	constructor(base: string) {
		this.base = path.resolve(base);
		if (path.parse(this.base).root === this.base) throw new Error("Refusing to export into a drive root. Choose a dedicated folder.");
	}
	private abs(rel: string): string {
		if (/^([/\\]|[a-zA-Z]:)/.test(rel)) throw new Error(`Absolute output paths are not allowed: ${rel}`);
		const clean = normPath(rel);
		if (!clean) throw new Error(`Unsafe output path: ${rel}`);
		const full = path.resolve(this.base, clean);
		if (full !== this.base && !full.startsWith(this.base + path.sep)) throw new Error(`Output path escapes the export folder: ${rel}`);
		return full;
	}
	async writeText(rel: string, content: string) { const p = this.abs(rel); await fs.promises.mkdir(path.dirname(p), { recursive: true }); await fs.promises.writeFile(p, content, "utf8"); }
	async writeBinary(rel: string, data: Uint8Array) { const p = this.abs(rel); await fs.promises.mkdir(path.dirname(p), { recursive: true }); await fs.promises.writeFile(p, data); }
	async remove(rel: string) { await fs.promises.rm(this.abs(rel), { force: true }); }
	async readText(rel: string) { try { return await fs.promises.readFile(this.abs(rel), "utf8"); } catch { return null; } }
}

/** Treats a normal folder as a vault. Link resolution imitates Obsidian's "shortest path" behaviour. */
export class FolderAdapter implements VaultAdapter {
	private files = new Map<string, VFile>();
	constructor(private root: string) {
		const walk = (dir: string) => {
			for (const e of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
				if (e.name.startsWith(".")) continue;
				const rel = dir ? `${dir}/${e.name}` : e.name;
				if (e.isDirectory()) walk(rel);
				else {
					const ext = path.extname(e.name).slice(1);
					this.files.set(rel, { path: rel, name: e.name, basename: path.basename(e.name, "." + ext), extension: ext, size: fs.statSync(path.join(root, rel)).size });
				}
			}
		};
		walk("");
	}
	readText(p: string) { return fs.promises.readFile(path.join(this.root, p), "utf8"); }
	async readBinary(p: string) { return new Uint8Array(await fs.promises.readFile(path.join(this.root, p))); }
	getFile(p: string) { return this.files.get(p) ?? null; }
	listNotes(folder: string) { return [...this.files.values()].filter((f) => f.extension.toLowerCase() === "md" && (folder === "" || f.path.startsWith(folder + "/"))); }
	resolveLink(link: string, source: string): VFile | null {
		const l = normPath(link);
		if (!l) return null;
		const withExt = /\.[a-z0-9]{1,5}$/i.test(l) ? [l] : [l + ".md", l];
		for (const c of withExt) {
			if (this.files.has(c)) return this.files.get(c)!;
			const rel = normPath(path.posix.join(path.posix.dirname(source), c));
			if (rel && this.files.has(rel)) return this.files.get(rel)!;
		}
		for (const c of withExt) {
			const hit = [...this.files.values()].find((f) => f.path === c || f.path.endsWith("/" + c));
			if (hit) return hit;
		}
		return null;
	}
}
