import pdfjsLib from "../vendor/pdfjs-lib.js.txt";
import pdfWorker from "../vendor/pdf-worker.mjs.txt";
import katexJs from "../vendor/katex.min.js.txt";
import katexCss from "../vendor/katex.css.txt";
import siteCss from "../runtime/site.css.txt";
import runtimeJs from "../runtime/runtime.js.txt";
import pdfViewerJs from "../runtime/pdf-viewer.js.txt";
import { ICONS } from "./icons";

export const VENDOR = { pdfjsLib, pdfWorker, katexJs, katexCss, siteCss };
/** Browser runtime = icon table + runtime + PDF viewer. */
export const RUNTIME_JS = `window.__OLWB_ICONS=${JSON.stringify(ICONS)};\n${runtimeJs}\n${pdfViewerJs}`;
