import type OfflineLearningWebsiteBuilder from "./main";
import type { CourseConfig, DesignConfig, ExportOptions, ProgressFn, SitePlan } from "../core/types";
import { planSite, writePlan, type WriteResult } from "../core/builder";
import { NodeWriter } from "../core/nodeio";
import { ObsidianAdapter } from "./adapter";
import { ensureDir, isAbsolute, join, openPath, tempPreviewDir } from "./system";

export interface ExportRequest { courses: CourseConfig[]; design: DesignConfig; options: ExportOptions; outputDir: string }
export interface ExportOutcome { plan: SitePlan; result: WriteResult; outputDir: string; entryPath: string }

export function validateOutputDir(dir: string): string | null {
	if (!dir.trim()) return "Choose an output folder first.";
	if (!isAbsolute(dir.trim())) return "The output folder must be a full path, for example C:\\Users\\me\\Site or /Users/me/Site.";
	return null;
}

export async function plan(plugin: OfflineLearningWebsiteBuilder, req: Omit<ExportRequest, "outputDir">, onProgress?: ProgressFn): Promise<SitePlan> {
	return planSite({ adapter: new ObsidianAdapter(plugin.app), courses: req.courses, design: req.design, options: req.options, onProgress });
}

export async function runExport(plugin: OfflineLearningWebsiteBuilder, req: ExportRequest, onProgress?: ProgressFn, existing?: SitePlan): Promise<ExportOutcome> {
	const bad = validateOutputDir(req.outputDir);
	if (bad) throw new Error(bad);
	const dir = req.outputDir.trim();
	ensureDir(dir);
	const adapter = new ObsidianAdapter(plugin.app);
	const p = existing ?? (await planSite({ adapter, courses: req.courses, design: req.design, options: req.options, onProgress }));
	const result = await writePlan(p, adapter, new NodeWriter(dir), onProgress);
	const entryPath = join(dir, p.entry);
	plugin.settings.outputDir = dir;
	plugin.settings.lastExport = { outputDir: dir, entry: p.entry, mode: req.options.mode, date: new Date().toISOString() };
	await plugin.saveSettings();
	return { plan: p, result, outputDir: dir, entryPath };
}

/** Export into a temporary folder and open the result in the default browser. */
export async function previewInBrowser(plugin: OfflineLearningWebsiteBuilder, req: Omit<ExportRequest, "outputDir">, onProgress?: ProgressFn): Promise<string> {
	const dir = tempPreviewDir();
	ensureDir(dir);
	const adapter = new ObsidianAdapter(plugin.app);
	const p = await planSite({ adapter, courses: req.courses, design: req.design, options: req.options, onProgress });
	await writePlan(p, adapter, new NodeWriter(dir), onProgress);
	const entry = join(dir, p.entry);
	if (!(await openPath(entry))) throw new Error(`Preview was written to ${entry} but could not be opened automatically. Open that file in your browser.`);
	return entry;
}
