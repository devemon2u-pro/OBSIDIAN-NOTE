import { App, TAbstractFile, TFile, TFolder, Vault } from "obsidian";
import type { VFile, VaultAdapter } from "../core/types";

/** Bridges the Obsidian vault to the Obsidian-free exporter core. Only vault files can ever be returned. */
export class ObsidianAdapter implements VaultAdapter {
	constructor(private app: App) {}

	private toV(f: TFile): VFile {
		return { path: f.path, name: f.name, basename: f.basename, extension: f.extension, size: f.stat.size };
	}
	private file(path: string): TFile | null {
		const f: TAbstractFile | null = this.app.vault.getAbstractFileByPath(path);
		return f instanceof TFile ? f : null;
	}
	async readText(path: string): Promise<string> {
		const f = this.file(path);
		if (!f) throw new Error(`File not found: ${path}`);
		return this.app.vault.cachedRead(f);
	}
	async readBinary(path: string): Promise<Uint8Array> {
		const f = this.file(path);
		if (!f) throw new Error(`File not found: ${path}`);
		return new Uint8Array(await this.app.vault.readBinary(f));
	}
	resolveLink(linkpath: string, sourcePath: string): VFile | null {
		const f = this.app.metadataCache.getFirstLinkpathDest(linkpath, sourcePath);
		return f ? this.toV(f) : null;
	}
	getFile(path: string): VFile | null {
		const f = this.file(path);
		return f ? this.toV(f) : null;
	}
	listNotes(folderPath: string): VFile[] {
		const root = folderPath === "" || folderPath === "/" ? this.app.vault.getRoot() : this.app.vault.getAbstractFileByPath(folderPath);
		const out: VFile[] = [];
		if (root instanceof TFolder) Vault.recurseChildren(root, (f) => { if (f instanceof TFile && f.extension.toLowerCase() === "md") out.push(this.toV(f)); });
		return out;
	}
}
