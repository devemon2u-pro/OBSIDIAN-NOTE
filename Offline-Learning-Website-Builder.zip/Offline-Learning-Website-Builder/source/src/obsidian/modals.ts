import { App, FuzzySuggestModal, Modal, Notice, Setting, TFile, TFolder } from "obsidian";
import type OfflineLearningWebsiteBuilder from "./main";
import type { CourseConfig, Progress } from "../core/types";
import { formatBytes } from "../core/util";
import { runExport, validateOutputDir, type ExportOutcome, type ExportRequest } from "./exporter";
import { defaultOutputDir, openPath, pickFolder, showInFolder } from "./system";

export class FolderSuggest extends FuzzySuggestModal<TFolder> {
	constructor(app: App, private onPick: (f: TFolder) => void, placeholder = "Choose a folder…") { super(app); this.setPlaceholder(placeholder); }
	getItems(): TFolder[] { return this.app.vault.getAllLoadedFiles().filter((f): f is TFolder => f instanceof TFolder); }
	getItemText(f: TFolder): string { return f.isRoot() ? "/ (whole vault)" : f.path; }
	onChooseItem(f: TFolder): void { this.onPick(f); }
}

export class NoteSuggest extends FuzzySuggestModal<TFile> {
	constructor(app: App, private onPick: (f: TFile) => void) { super(app); this.setPlaceholder("Choose a note…"); }
	getItems(): TFile[] { return this.app.vault.getMarkdownFiles(); }
	getItemText(f: TFile): string { return f.path; }
	onChooseItem(f: TFile): void { this.onPick(f); }
}

export class ImageSuggest extends FuzzySuggestModal<TFile> {
	constructor(app: App, private onPick: (f: TFile) => void) { super(app); this.setPlaceholder("Choose a logo image (png, jpg, svg, webp)…"); }
	getItems(): TFile[] { return this.app.vault.getFiles().filter((f) => ["png", "jpg", "jpeg", "svg", "webp", "gif"].includes(f.extension.toLowerCase())); }
	getItemText(f: TFile): string { return f.path; }
	onChooseItem(f: TFile): void { this.onPick(f); }
}

export function courseFromFolder(f: TFolder): CourseConfig {
	return { id: "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: f.isRoot() ? "Vault" : f.name, description: "", category: "Courses", featured: false, kind: "folder", path: f.isRoot() ? "" : f.path, icon: "" };
}
export function courseFromNote(f: TFile): CourseConfig {
	return { id: "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), title: f.basename, description: "", category: "Courses", featured: false, kind: "note", path: f.path, icon: "" };
}

/** Output-folder field + progress bar + log. Shared by the wizard (step 6) and the quick-export dialog. */
export class ExportPanel {
	private bar!: HTMLElement;
	private status!: HTMLElement;
	private log!: HTMLElement;
	private startBtn!: HTMLButtonElement;
	private running = false;

	constructor(private plugin: OfflineLearningWebsiteBuilder, private el: HTMLElement, private getReq: () => Omit<ExportRequest, "outputDir">, private onDone: (o: ExportOutcome) => void) { this.render(); }

	private render(): void {
		const s = this.plugin.settings;
		if (!s.outputDir) s.outputDir = defaultOutputDir();
		new Setting(this.el).setName("Output folder").setDesc("A normal folder on your computer. It is created if needed. Only files made by this plugin are ever replaced.")
			.addText((t) => { t.setValue(s.outputDir).onChange((v) => { s.outputDir = v.trim(); void this.plugin.saveSettings(); }); t.inputEl.addClass("olwb-wide"); })
			.addButton((b) => b.setButtonText("Browse…").onClick(async () => {
				const p = await pickFolder(s.outputDir);
				if (p) { s.outputDir = p; await this.plugin.saveSettings(); this.el.empty(); this.render(); } else new Notice("Could not open a folder picker here. Type or paste the folder path instead.");
			}));
		const row = this.el.createDiv({ cls: "olwb-actions" });
		this.startBtn = row.createEl("button", { text: "Start export", cls: "mod-cta" });
		this.startBtn.onclick = () => void this.start();
		const prog = this.el.createDiv({ cls: "olwb-progress" });
		this.bar = prog.createDiv({ cls: "olwb-progress-bar" });
		this.status = this.el.createDiv({ cls: "olwb-status" });
		this.log = this.el.createDiv({ cls: "olwb-log" });
	}

	private async start(): Promise<void> {
		if (this.running) return;
		const dir = this.plugin.settings.outputDir;
		const bad = validateOutputDir(dir);
		if (bad) { this.fail(bad); return; }
		this.running = true;
		this.startBtn.disabled = true;
		this.log.empty();
		this.status.setText("Starting…");
		this.status.removeClass("olwb-error");
		let last = 0;
		const onProgress = (p: Progress) => {
			const now = Date.now();
			if (now - last < 60 && p.done < p.total) return;
			last = now;
			this.bar.style.width = `${p.total ? Math.round((p.done / p.total) * 100) : 0}%`;
			this.status.setText(`${p.phase}${p.message ? " — " + p.message : ""}`);
		};
		try {
			const out = await runExport(this.plugin, { ...this.getReq(), outputDir: dir }, onProgress);
			this.bar.style.width = "100%";
			this.status.setText(`Done: ${out.result.files} files, ${formatBytes(out.result.bytes)}.`);
			this.onDone(out);
		} catch (e) {
			this.fail((e as Error).message || String(e));
			console.error("[Offline Learning Website Builder]", e);
		} finally {
			this.running = false;
			this.startBtn.disabled = false;
		}
	}

	private fail(msg: string): void {
		this.status.setText(`Export failed: ${msg}`);
		this.status.addClass("olwb-error");
	}
}

export function renderOutcome(el: HTMLElement, out: ExportOutcome): void {
	el.createEl("h3", { text: "Export complete" });
	el.createEl("p", { text: `${out.plan.stats.courses} course(s), ${out.plan.stats.lessons} lesson(s), ${out.plan.stats.assets} attachment(s). ${out.result.files} files written.` });
	const code = el.createEl("p"); code.createEl("code", { text: out.entryPath });
	const row = el.createDiv({ cls: "olwb-actions" });
	row.createEl("button", { text: "Open in browser", cls: "mod-cta" }).onclick = async () => { if (!(await openPath(out.entryPath))) new Notice("Could not open automatically. Open the file shown above."); };
	row.createEl("button", { text: "Show folder" }).onclick = () => { if (!showInFolderSafe(out.entryPath)) void openPath(out.outputDir); };
	if (out.plan.warnings.length) {
		el.createEl("h4", { text: `Warnings (${out.plan.warnings.length})` });
		const ul = el.createEl("ul", { cls: "olwb-warnings" });
		for (const w of out.plan.warnings.slice(0, 40)) ul.createEl("li", { text: w });
	}
}
function showInFolderSafe(p: string): boolean { try { showInFolder(p); return true; } catch { return false; } }

export class QuickExportModal extends Modal {
	private outcome: ExportOutcome | null = null;
	constructor(private plugin: OfflineLearningWebsiteBuilder, private title: string, private getReq: () => Omit<ExportRequest, "outputDir">, private note = "") { super(plugin.app); }
	onOpen(): void {
		const { contentEl } = this;
		this.modalEl.addClass("olwb-modal");
		contentEl.createEl("h2", { text: this.title });
		const req = this.getReq();
		if (this.note) contentEl.createEl("p", { text: this.note, cls: "setting-item-description" });
		if (req.options.mode === "single") {
			new Setting(contentEl).setName("Embed everything inside one HTML file").setDesc("On: one file you can email or copy. Off: the page plus a folder of assets (better for big media).")
				.addToggle((t) => t.setValue(req.options.embed).onChange((v) => { req.options.embed = v; this.plugin.settings.options.embed = v; void this.plugin.saveSettings(); }));
		}
		const panel = contentEl.createDiv();
		const result = contentEl.createDiv({ cls: "olwb-result" });
		new ExportPanel(this.plugin, panel, () => req, (o) => { this.outcome = o; result.empty(); renderOutcome(result, o); });
	}
	onClose(): void { this.contentEl.empty(); void this.outcome; }
}
