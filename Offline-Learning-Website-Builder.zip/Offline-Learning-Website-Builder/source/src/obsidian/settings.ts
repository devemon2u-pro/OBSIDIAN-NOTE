import { App, Notice, PluginSettingTab, Setting } from "obsidian";
import type OfflineLearningWebsiteBuilder from "./main";
import type { CourseConfig, DesignConfig, ExportOptions } from "../core/types";
import { defaultDesign, defaultOptions } from "../core/design";
import { pickFolder } from "./system";

export interface LastExport { outputDir: string; entry: string; mode: "site" | "single"; date: string }
export interface PluginSettings {
	courses: CourseConfig[];
	design: DesignConfig;
	options: ExportOptions;
	outputDir: string;
	lastExport: LastExport | null;
}
export const DEFAULT_SETTINGS = (): PluginSettings => ({ courses: [], design: defaultDesign(), options: defaultOptions(), outputDir: "", lastExport: null });

export class BuilderSettingTab extends PluginSettingTab {
	constructor(app: App, private plugin: OfflineLearningWebsiteBuilder) { super(app, plugin); }

	display(): void {
		const { containerEl } = this;
		containerEl.empty();
		const s = this.plugin.settings;
		const save = () => this.plugin.saveSettings();

		new Setting(containerEl).setName("Open the builder").setDesc("The step-by-step wizard: choose notes, design the site, export.")
			.addButton((b) => b.setButtonText("Open Learning Website Builder").setCta().onClick(() => this.plugin.openWizard()));

		new Setting(containerEl).setName("Export settings").setHeading();
		new Setting(containerEl).setName("Default output folder").setDesc("Where exported websites are written (a normal folder on your computer, outside or inside the vault).")
			.addText((t) => t.setPlaceholder("C:\\Users\\me\\OfflineLearningWebsite").setValue(s.outputDir).onChange(async (v) => { s.outputDir = v.trim(); await save(); }))
			.addButton((b) => b.setButtonText("Browse…").onClick(async () => { const p = await pickFolder(s.outputDir); if (p) { s.outputDir = p; await save(); this.display(); } else new Notice("Type or paste the folder path instead."); }));
		new Setting(containerEl).setName("Large file warning (MB)").setDesc("Attachments bigger than this trigger a warning during export.")
			.addText((t) => t.setValue(String(s.options.largeFileMB)).onChange(async (v) => { const n = Number(v); if (n > 0) { s.options.largeFileMB = n; await save(); } }));
		new Setting(containerEl).setName("Search index size per lesson (characters)").setDesc("Higher = better in-site search, bigger website. Default 30000.")
			.addText((t) => t.setValue(String(s.options.searchChars)).onChange(async (v) => { const n = Number(v); if (n >= 1000) { s.options.searchChars = Math.round(n); await save(); } }));
		new Setting(containerEl).setName("Reset").setDesc("Clear the saved course list and design (does not touch your notes or exported files).")
			.addButton((b) => b.setButtonText("Reset builder data").setWarning().onClick(async () => { Object.assign(s, DEFAULT_SETTINGS()); await save(); this.display(); new Notice("Builder data reset."); }));

		new Setting(containerEl).setName("Help for beginners").setHeading();
		const h = containerEl.createDiv({ cls: "olwb-help" });
		h.createEl("p", { text: "1. Click the graduation-cap icon in the left ribbon (or run “Open Learning Website Builder” from the command palette)." });
		h.createEl("p", { text: "2. Pick what to export: a folder becomes a course and every note inside it becomes a lesson. A single note becomes a one-lesson course." });
		h.createEl("p", { text: "3. Choose a look (presets, colours, fonts), then export. Open index.html in the output folder with any browser. No internet is needed." });
		h.createEl("p", { text: "4. Later, run “Update Existing Website” to re-export with your latest notes into the same folder." });
		h.createEl("p", { text: "Attachments (PDF, images, audio, video) are included only when a selected note links or embeds them. Nothing else from your vault is exported." });
		h.createEl("p", { text: "Not supported offline: remote images, Mermaid diagrams, Dataview/other plugin output (shown as source or a visible placeholder)." });
	}
}
