import { Notice, Plugin, TFile, TFolder } from "obsidian";
import type { CourseConfig } from "../core/types";
import { BuilderSettingTab, DEFAULT_SETTINGS, type PluginSettings } from "./settings";
import { WizardModal } from "./wizard";
import { FolderSuggest, QuickExportModal, courseFromFolder, courseFromNote } from "./modals";
import { previewInBrowser, runExport } from "./exporter";
import { openPath } from "./system";

export default class OfflineLearningWebsiteBuilder extends Plugin {
	settings!: PluginSettings;

	async onload(): Promise<void> {
		await this.loadSettings();

		this.addRibbonIcon("graduation-cap", "Offline Learning Website Builder", () => this.openWizard());

		this.addCommand({ id: "open-builder", name: "Open Learning Website Builder", callback: () => this.openWizard() });
		this.addCommand({
			id: "export-current-note", name: "Export Current Note as HTML",
			checkCallback: (checking) => {
				const f = this.app.workspace.getActiveFile();
				if (!f || f.extension !== "md") return false;
				if (!checking) this.exportNote(f);
				return true;
			},
		});
		this.addCommand({ id: "export-selected-folder", name: "Export Selected Folder as Website", callback: () => new FolderSuggest(this.app, (f) => this.exportFolder(f)).open() });
		this.addCommand({ id: "export-entire-website", name: "Export Entire Website", callback: () => this.exportEntire() });
		this.addCommand({ id: "preview-website", name: "Preview Website", callback: () => void this.previewSaved() });
		this.addCommand({ id: "update-existing-website", name: "Update Existing Website", callback: () => void this.updateExisting() });
		this.addCommand({ id: "open-export-folder", name: "Open Export Folder", callback: () => void this.openExportFolder() });

		this.registerEvent(this.app.workspace.on("file-menu", (menu, file) => {
			if (file instanceof TFile && file.extension === "md") {
				menu.addItem((i) => i.setTitle("Export as offline HTML").setIcon("file-down").onClick(() => this.exportNote(file)));
			} else if (file instanceof TFolder) {
				menu.addItem((i) => i.setTitle("Export folder as learning website").setIcon("graduation-cap").onClick(() => this.exportFolder(file)));
				menu.addItem((i) => i.setTitle("Add folder as a course").setIcon("plus").onClick(() => this.addCourse(courseFromFolder(file))));
			}
		}));
		this.registerEvent(this.app.workspace.on("editor-menu", (menu, _editor, view) => {
			const f = view.file;
			if (f && f.extension === "md") menu.addItem((i) => i.setTitle("Export this note as offline HTML").setIcon("file-down").onClick(() => this.exportNote(f)));
		}));

		this.addSettingTab(new BuilderSettingTab(this.app, this));
	}

	async loadSettings(): Promise<void> {
		const saved = (await this.loadData()) as Partial<PluginSettings> | null;
		const d = DEFAULT_SETTINGS();
		this.settings = { ...d, ...saved, design: { ...d.design, ...saved?.design }, options: { ...d.options, ...saved?.options }, courses: saved?.courses ?? [] };
	}
	async saveSettings(): Promise<void> { await this.saveData(this.settings); }

	openWizard(step = 0): void { new WizardModal(this, step).open(); }

	private addCourse(c: CourseConfig): void {
		if (!this.settings.courses.some((x) => x.path === c.path)) this.settings.courses.push(c);
		void this.saveSettings();
		new Notice(`Added “${c.title}” to the learning website courses.`);
	}

	private exportNote(f: TFile): void {
		const course = courseFromNote(f);
		new QuickExportModal(this, `Export “${f.basename}” as HTML`, () => ({ courses: [course], design: { ...this.settings.design }, options: { ...this.settings.options, mode: "single" } }), "The note and the attachments it links will be exported as a standalone page.").open();
	}

	private exportFolder(folder: TFolder): void {
		const subs = folder.children.filter((c): c is TFolder => c instanceof TFolder && !c.name.startsWith("."));
		const hasLooseNotes = folder.children.some((c) => c instanceof TFile && c.extension === "md");
		// Sub-folders only (no notes directly inside): each sub-folder becomes a course.
		// Otherwise the whole folder (including sub-folders) is one course, so no note is silently dropped.
		const asCourses = subs.length > 0 && !hasLooseNotes;
		const courses: CourseConfig[] = asCourses ? subs.map(courseFromFolder) : [courseFromFolder(folder)];
		const design = { ...this.settings.design, title: folder.isRoot() ? this.settings.design.title : folder.name };
		new QuickExportModal(this, `Export “${folder.name || "vault"}” as a website`, () => ({ courses, design, options: { ...this.settings.options, mode: "site" } }),
			asCourses ? "Each sub-folder becomes a course; every note inside is a lesson." : "This folder becomes one course; every note inside (including sub-folders) is a lesson.").open();
	}

	private exportEntire(): void {
		if (!this.settings.courses.length) { new Notice("Choose your courses first."); this.openWizard(1); return; }
		new QuickExportModal(this, "Export entire website", () => ({ courses: this.settings.courses, design: this.settings.design, options: { ...this.settings.options, mode: "site" } }), `${this.settings.courses.length} course(s) from the course manager.`).open();
	}

	private async previewSaved(): Promise<void> {
		if (!this.settings.courses.length) { new Notice("Choose your courses first."); this.openWizard(1); return; }
		const n = new Notice("Building preview…", 0);
		try { await previewInBrowser(this, { courses: this.settings.courses, design: this.settings.design, options: { ...this.settings.options, mode: "site" } }); n.hide(); }
		catch (e) { n.hide(); new Notice((e as Error).message, 8000); console.error(e); }
	}

	private async updateExisting(): Promise<void> {
		const last = this.settings.lastExport;
		if (!last || last.mode !== "site") { new Notice("No previous website export found. Run “Export Entire Website” first."); return; }
		if (!this.settings.courses.length) { new Notice("The course list is empty. Add courses in the builder first."); this.openWizard(1); return; }
		const n = new Notice("Updating website…", 0);
		try {
			const out = await runExport(this, { courses: this.settings.courses, design: this.settings.design, options: { ...this.settings.options, mode: "site" }, outputDir: last.outputDir }, (p) => n.setMessage(`Updating website… ${p.message ?? p.phase}`));
			n.hide();
			new Notice(`Website updated: ${out.result.files} files${out.plan.warnings.length ? `, ${out.plan.warnings.length} warning(s)` : ""}.`, 6000);
		} catch (e) { n.hide(); new Notice(`Update failed: ${(e as Error).message}`, 10000); console.error(e); }
	}

	private async openExportFolder(): Promise<void> {
		const dir = this.settings.lastExport?.outputDir || this.settings.outputDir;
		if (!dir) { new Notice("Nothing exported yet."); return; }
		if (!(await openPath(dir))) new Notice(`Could not open the folder automatically: ${dir}`, 8000);
	}
}
