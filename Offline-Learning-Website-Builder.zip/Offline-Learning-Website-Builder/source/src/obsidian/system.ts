/** Desktop helpers (Electron). All of them degrade gracefully: if something is unavailable the caller shows a hint. */
import * as os from "os";
import * as path from "path";
import * as fs from "fs";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Any = any;
const req = (m: string): Any => { try { return (window as Any).require(m); } catch { return null; } };

export async function pickFolder(defaultPath?: string): Promise<string | null> {
	const electron = req("electron");
	const remote = electron?.remote ?? req("@electron/remote");
	if (remote?.dialog?.showOpenDialog) {
		try {
			const r = await remote.dialog.showOpenDialog({ properties: ["openDirectory", "createDirectory"], defaultPath: defaultPath || undefined });
			return r.canceled || !r.filePaths?.length ? null : (r.filePaths[0] as string);
		} catch { /* fall through */ }
	}
	return new Promise((resolve) => {
		const input = document.createElement("input");
		input.type = "file";
		(input as Any).webkitdirectory = true;
		input.onchange = () => {
			const f = input.files?.[0] as Any;
			if (!f) return resolve(null);
			const abs: string | undefined = f.path || electron?.webUtils?.getPathForFile?.(f);
			const rel: string = f.webkitRelativePath || "";
			if (!abs || !rel) return resolve(null);
			const sep = abs.includes("\\") ? "\\" : "/";
			const tail = rel.split("/").join(sep);
			resolve(abs.endsWith(tail) ? abs.slice(0, abs.length - tail.length) + rel.split("/")[0] : null);
		};
		input.addEventListener("cancel", () => resolve(null));
		input.click();
	});
}

export async function openPath(p: string): Promise<boolean> {
	const shell = req("electron")?.shell;
	if (!shell) return false;
	const err: string = await shell.openPath(p);
	return !err;
}

export function showInFolder(p: string): void { req("electron")?.shell?.showItemInFolder?.(p); }
export function tempPreviewDir(): string { return path.join(os.tmpdir(), "olwb-preview-" + Date.now()); }
export function defaultOutputDir(): string { return path.join(os.homedir(), "OfflineLearningWebsite"); }
export function isAbsolute(p: string): boolean { return path.isAbsolute(p); }
export function join(...p: string[]): string { return path.join(...p); }
export function ensureDir(p: string): void { fs.mkdirSync(p, { recursive: true }); }
export async function copyText(t: string): Promise<void> { await navigator.clipboard.writeText(t); }
