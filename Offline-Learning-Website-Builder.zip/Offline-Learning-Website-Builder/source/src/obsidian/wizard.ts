import { Modal, Notice, Setting, setIcon, TFile, TFolder } from "obsidian";
import type OfflineLearningWebsiteBuilder from "./main";
import type { CourseConfig, SitePlan } from "../core/types";
import { FONT_LABELS, PRESETS, applyPreset } from "../core/design";
import { previewHomeHtml, type PreviewCourse } from "../core/preview";
import { formatBytes, mimeFor, toBase64 } from "../core/util";
import { ObsidianAdapter } from "./adapter";
import { plan as planExport, previewInBrowser, type ExportOutcome } from "./exporter";
import { ExportPanel, FolderSuggest, ImageSuggest, NoteSuggest, courseFromFolder, courseFromNote, renderOutcome } from "./modals";
import { copyText, openPath } from "./system";

const STEPS = ["Export type", "Notes & folders", "Design", "Media", "Preview", "Export", "Finished"];

function debounce<A extends unknown[]>(fn: (...a: A) => void, ms: number): (...a: A) => void {
	let t: number | undefined;
	return (...a: A) => { window.clearTimeout(t); t = window.setTimeout(() => fn(...a), ms); };
}

export class WizardModal extends Modal {
	private step: number;
	private scan: { sig: string; plan?: SitePlan; error?: string; busy: boolean } | null = null;
	private outcome: ExportOutcome | null = null;
	private logoCache = new Map<string, string>();

	constructor(private plugin: OfflineLearningWebsiteBuilder, startStep = 0) { super(plugin.app); this.step = startStep; }

	private get s() { return this.plugin.settings; }
	private save = debounce(() => void this.plugin.saveSettings(), 300);

	onOpen(): void { this.modalEl.addClass("olwb-modal", "olwb-wizard"); this.render(); }
	onClose(): void { this.contentEl.empty(); void this.plugin.saveSettings(); }

	private canGoNext(): string | null {
		if (this.step === 1 && !this.s.courses.length) return "Add at least one folder or note.";
		if (this.step === 1 && this.s.options.mode === "single" && this.s.courses.length > 1) return "Individual HTML export takes one course only.";
		return null;
	}

	private render(): void {
		const el = this.contentEl;
		el.empty();
		const head = el.createDiv({ cls: "olwb-steps" });
		STEPS.forEach((n, i) => {
			const d = head.createDiv({ cls: "olwb-step" + (i === this.step ? " is-active" : i < this.step ? " is-done" : "") });
			d.createSpan({ cls: "olwb-step-n", text: String(i + 1) });
			d.createSpan({ cls: "olwb-step-t", text: n });
		});
		const body = el.createDiv({ cls: "olwb-body" });
		[this.stepType, this.stepNotes, this.stepDesign, this.stepMedia, this.stepPreview, this.stepExport, this.stepDone][this.step].call(this, body);
		const foot = el.createDiv({ cls: "olwb-foot" });
		if (this.step > 0 && this.step < 6) foot.createEl("button", { text: "Back" }).onclick = () => { this.step--; this.render(); };
		foot.createDiv({ cls: "olwb-spacer" });
		if (this.step < 5) {
			const next = foot.createEl("button", { text: "Next", cls: "mod-cta" });
			next.onclick = () => { const why = this.canGoNext(); if (why) { new Notice(why); return; } this.step++; this.render(); };
		}
		if (this.step === 6) foot.createEl("button", { text: "Close", cls: "mod-cta" }).onclick = () => this.close();
	}

	// ---------------------------------------------------------------- step 1
	private stepType(el: HTMLElement): void {
		el.createEl("h2", { text: "What do you want to export?" });
		const row = el.createDiv({ cls: "olwb-cards" });
		const card = (mode: "single" | "site", title: string, text: string, icon: string) => {
			const c = row.createDiv({ cls: "olwb-card" + (this.s.options.mode === mode ? " is-selected" : "") });
			setIcon(c.createDiv({ cls: "olwb-card-icon" }), icon);
			c.createEl("h3", { text: title });
			c.createEl("p", { text });
			c.onclick = () => { this.s.options.mode = mode; if (mode === "single" && this.s.courses.length > 1) new Notice("Individual export uses one course. Keep only one in the next step."); void this.plugin.saveSettings(); this.render(); };
		};
		card("site", "Complete learning website", "A homepage plus one page per course, with search, categories, bookmarks and navigation. Open index.html.", "globe");
		card("single", "Individual HTML", "One note or course as a single page. Can be one standalone file with everything embedded.", "file-text");
		if (this.s.options.mode === "single") {
			new Setting(el).setName("Embed everything in the HTML file").setDesc("On: a single file with PDFs, media and images inside (large files make it big). Off: page + assets folder.")
				.addToggle((t) => t.setValue(this.s.options.embed).onChange((v) => { this.s.options.embed = v; this.save(); }));
		}
		el.createEl("p", { cls: "setting-item-description", text: "Both options work completely offline: no CDN, no web fonts, no server. PDFs open in a built-in viewer instead of your browser's plugin." });
	}

	// ---------------------------------------------------------------- step 2
	private stepNotes(el: HTMLElement): void {
		const single = this.s.options.mode === "single";
		el.createEl("h2", { text: single ? "Choose the note or folder" : "Choose your courses" });
		el.createEl("p", { cls: "setting-item-description", text: "A folder becomes a course (each note inside is a lesson). A single note becomes a one-lesson course. Linked attachments are included automatically; nothing else is." });
		const bar = el.createDiv({ cls: "olwb-actions" });
		const add = (c: CourseConfig) => { if (single) this.s.courses = [c]; else this.s.courses.push(c); this.save(); this.render(); };
		bar.createEl("button", { text: "Add folder…", cls: "mod-cta" }).onclick = () => new FolderSuggest(this.app, (f) => add(courseFromFolder(f))).open();
		bar.createEl("button", { text: "Add note…" }).onclick = () => new NoteSuggest(this.app, (f) => add(courseFromNote(f))).open();
		if (!single) {
			bar.createEl("button", { text: "Add every top-level folder" }).onclick = () => {
				const known = new Set(this.s.courses.map((c) => c.path));
				let n = 0;
				for (const f of this.app.vault.getRoot().children) if (f instanceof TFolder && !f.name.startsWith(".") && !known.has(f.path)) { this.s.courses.push(courseFromFolder(f)); n++; }
				new Notice(n ? `Added ${n} folder(s).` : "No new top-level folders found."); this.save(); this.render();
			};
		}
		const cats = el.createEl("datalist"); cats.id = "olwb-cats";
		for (const c of new Set(this.s.courses.map((x) => x.category))) cats.createEl("option", { value: c });
		if (!this.s.courses.length) el.createDiv({ cls: "olwb-empty", text: "No courses yet. Use “Add folder…” or “Add note…”." });
		this.s.courses.forEach((c, i) => {
			const row = el.createDiv({ cls: "olwb-course" });
			const top = row.createDiv({ cls: "olwb-course-top" });
			const title = top.createEl("input", { type: "text", cls: "olwb-title", attr: { "aria-label": "Course title" } }); title.value = c.title; title.oninput = () => { c.title = title.value; this.save(); };
			const icon = top.createEl("input", { type: "text", cls: "olwb-icon", attr: { placeholder: "😀", "aria-label": "Icon (emoji or letters)", maxlength: "4" } }); icon.value = c.icon; icon.oninput = () => { c.icon = icon.value; this.save(); };
			const mv = top.createDiv({ cls: "olwb-move" });
			const btn = (ic: string, label: string, fn: () => void, disabled = false) => { const b = mv.createEl("button", { cls: "clickable-icon", attr: { "aria-label": label } }); setIcon(b, ic); b.disabled = disabled; b.onclick = fn; };
			btn("arrow-up", "Move up", () => { [this.s.courses[i - 1], this.s.courses[i]] = [this.s.courses[i], this.s.courses[i - 1]]; this.save(); this.render(); }, i === 0);
			btn("arrow-down", "Move down", () => { [this.s.courses[i + 1], this.s.courses[i]] = [this.s.courses[i], this.s.courses[i + 1]]; this.save(); this.render(); }, i === this.s.courses.length - 1);
			btn("trash", "Remove course", () => { this.s.courses.splice(i, 1); this.save(); this.render(); });
			const mid = row.createDiv({ cls: "olwb-course-mid" });
			const cat = mid.createEl("input", { type: "text", attr: { list: "olwb-cats", placeholder: "Category", "aria-label": "Category" } }); cat.value = c.category; cat.oninput = () => { c.category = cat.value || "Courses"; this.save(); };
			const feat = mid.createEl("label", { cls: "olwb-feat" }); const cb = feat.createEl("input", { type: "checkbox" }); cb.checked = c.featured; cb.onchange = () => { c.featured = cb.checked; this.save(); }; feat.createSpan({ text: " Featured" });
			const desc = row.createEl("textarea", { attr: { rows: "2", placeholder: "Description (shown on the course card). Leave empty to use the note's own description.", "aria-label": "Description" } }); desc.value = c.description; desc.oninput = () => { c.description = desc.value; this.save(); };
			row.createDiv({ cls: "olwb-path", text: `${c.kind === "folder" ? "Folder" : "Note"}: ${c.path || "/ (whole vault)"}` });
		});
	}

	// ---------------------------------------------------------------- step 3
	private async logoUri(): Promise<string | null> {
		const p = this.s.design.logoPath;
		if (!p) return null;
		if (this.logoCache.has(p)) return this.logoCache.get(p)!;
		const f = this.app.vault.getAbstractFileByPath(p);
		if (!(f instanceof TFile)) return null;
		const uri = `data:${mimeFor(f.extension)};base64,${toBase64(new Uint8Array(await this.app.vault.readBinary(f)))}`;
		this.logoCache.set(p, uri);
		return uri;
	}
	private previewCourses(): PreviewCourse[] {
		const ad = new ObsidianAdapter(this.app);
		const list = this.s.courses.length ? this.s.courses : [{ title: "Sample course", description: "Your courses appear here.", category: "Courses", featured: true, kind: "note", path: "", icon: "", id: "x" } as CourseConfig];
		return list.map((c) => { const n = c.kind === "note" ? 1 : Math.max(1, ad.listNotes(c.path).length); return { title: c.title, description: c.description || `${n} lesson${n === 1 ? "" : "s"}`, category: c.category, featured: c.featured, icon: c.icon, lessons: n, minutes: n * 3 }; });
	}
	private mountPreview(host: HTMLElement): () => void {
		const frame = host.createEl("iframe", { cls: "olwb-frame", attr: { sandbox: "allow-scripts", title: "Homepage preview" } });
		let token = 0;
		return () => { const my = ++token; void this.logoUri().then((uri) => { if (my === token) frame.srcdoc = previewHomeHtml(this.s.design, this.previewCourses(), uri); }); };
	}

	private stepDesign(el: HTMLElement): void {
		el.createEl("h2", { text: "Design your website" });
		const wrap = el.createDiv({ cls: "olwb-split" });
		const left = wrap.createDiv({ cls: "olwb-left" });
		const right = wrap.createDiv({ cls: "olwb-right" });
		right.createDiv({ cls: "olwb-hint", text: "Live preview (links are disabled here)" });
		const refresh = this.mountPreview(right);
		const d = this.s.design;
		const upd = () => { this.save(); refresh(); };
		new Setting(left).setName("Website title").addText((t) => t.setValue(d.title).onChange((v) => { d.title = v; upd(); }));
		new Setting(left).setName("Description").addTextArea((t) => { t.setValue(d.description).onChange((v) => { d.description = v; upd(); }); t.inputEl.rows = 2; });
		new Setting(left).setName("Logo").setDesc(d.logoPath || "None (a letter badge is used)")
			.addButton((b) => b.setButtonText("Choose…").onClick(() => new ImageSuggest(this.app, (f) => { d.logoPath = f.path; this.save(); this.render(); }).open()))
			.addExtraButton((b) => b.setIcon("x").setTooltip("Remove logo").onClick(() => { d.logoPath = ""; this.save(); this.render(); }));
		const presets = left.createDiv({ cls: "olwb-presets" });
		for (const p of PRESETS) {
			const b = presets.createDiv({ cls: "olwb-preset" + (d.preset === p.id ? " is-selected" : "") });
			b.createSpan({ cls: "olwb-swatch" }).style.background = p.design.accent ?? "#888";
			b.createDiv({ cls: "olwb-preset-name", text: p.name }); b.createDiv({ cls: "olwb-preset-blurb", text: p.blurb });
			b.onclick = () => { this.s.design = applyPreset(d, p.id); this.save(); this.render(); };
		}
		const dd = (name: string, opts: Record<string, string>, get: () => string, set: (v: string) => void) => new Setting(left).setName(name).addDropdown((x) => { for (const [k, v] of Object.entries(opts)) x.addOption(k, v); x.setValue(get()).onChange((v) => { set(v); upd(); }); });
		dd("Default theme", { light: "Light", dark: "Dark", system: "System default" }, () => d.theme, (v) => (d.theme = v as typeof d.theme));
		new Setting(left).setName("Accent colour").addColorPicker((c) => c.setValue(d.accent).onChange((v) => { d.accent = v; upd(); }));
		dd("Homepage layout", { split: "Split hero", centered: "Centered hero", compact: "Compact" }, () => d.heroLayout, (v) => (d.heroLayout = v as typeof d.heroLayout));
		dd("Course card style", { elevated: "Elevated", outlined: "Outlined", flat: "Flat", cover: "Large cover" }, () => d.cardStyle, (v) => (d.cardStyle = v as typeof d.cardStyle));
		dd("Font", FONT_LABELS, () => d.font, (v) => (d.font = v as typeof d.font));
		dd("Navigation bar", { solid: "Solid", glass: "Translucent" }, () => d.navStyle, (v) => (d.navStyle = v as typeof d.navStyle));
		new Setting(left).setName("Corner roundness").addSlider((s) => s.setLimits(0, 28, 1).setValue(d.radius).setDynamicTooltip().onChange((v) => { d.radius = v; upd(); }));
		new Setting(left).setName("Show breadcrumbs on course pages").addToggle((t) => t.setValue(d.showBreadcrumb).onChange((v) => { d.showBreadcrumb = v; upd(); }));
		new Setting(left).setName("Show previous/next course buttons").addToggle((t) => t.setValue(d.showCourseNav).onChange((v) => { d.showCourseNav = v; upd(); }));
		new Setting(left).setName("Footer text").addText((t) => t.setValue(d.footerText).onChange((v) => { d.footerText = v; upd(); }));
		left.createEl("p", { cls: "setting-item-description", text: "Fonts use the system font stacks so nothing needs to be downloaded; the exact look depends on the viewer's device." });
		refresh();
	}

	// ---------------------------------------------------------------- step 4 / 5
	private sig(): string { return JSON.stringify([this.s.courses, this.s.options, this.s.design.logoPath, this.s.design.title]); }
	private async runScan(then: () => void): Promise<void> {
		const sig = this.sig();
		if (this.scan?.sig === sig && (this.scan.plan || this.scan.busy)) { then(); return; }
		this.scan = { sig, busy: true };
		then();
		try {
			const p = await planExport(this.plugin, { courses: this.s.courses, design: this.s.design, options: this.s.options });
			this.scan = { sig, plan: p, busy: false };
		} catch (e) { this.scan = { sig, error: (e as Error).message, busy: false }; }
		if (this.step === 3 || this.step === 4) this.render();
	}
	private summary(el: HTMLElement): void {
		const sc = this.scan;
		if (!sc || sc.busy) { el.createDiv({ cls: "olwb-status", text: "Scanning notes and attachments…" }); return; }
		if (sc.error) { el.createDiv({ cls: "olwb-status olwb-error", text: sc.error }); return; }
		const p = sc.plan!;
		const kinds: Record<string, { n: number; b: number }> = {};
		for (const a of p.assets) { (kinds[a.kind] ??= { n: 0, b: 0 }).n++; kinds[a.kind].b += a.size; }
		const t = el.createEl("table", { cls: "olwb-table" });
		const row = (a: string, b: string) => { const r = t.createEl("tr"); r.createEl("td", { text: a }); r.createEl("td", { text: b }); };
		row("Courses / lessons", `${p.stats.courses} / ${p.stats.lessons}`);
		for (const [k, v] of Object.entries(kinds)) row(`Attachments: ${k}`, `${v.n} file(s), ${formatBytes(v.b)}`);
		row("Estimated output size", formatBytes(p.estimatedBytes));
		if (p.warnings.length) { el.createEl("h4", { text: `Warnings (${p.warnings.length})` }); const ul = el.createEl("ul", { cls: "olwb-warnings" }); for (const w of p.warnings.slice(0, 25)) ul.createEl("li", { text: w }); }
		else el.createDiv({ cls: "olwb-ok", text: "No problems found." });
	}
	private stepMedia(el: HTMLElement): void {
		el.createEl("h2", { text: "Media and attachments" });
		el.createEl("p", { cls: "setting-item-description", text: "Only files linked from the selected notes are included. Choose what types to export." });
		const o = this.s.options;
		const tg = (name: string, desc: string, k: "includePdf" | "includeAudio" | "includeVideo" | "includeOther") => new Setting(el).setName(name).setDesc(desc).addToggle((t) => t.setValue(o[k]).onChange((v) => { o[k] = v; this.save(); this.scan = null; void this.runScan(() => this.render()); }));
		tg("PDFs", "Shown in a built-in viewer with search, zoom and download.", "includePdf");
		tg("Audio", "MP3, WAV, OGG, M4A … with a custom player.", "includeAudio");
		tg("Video", "MP4, WebM … (playback depends on the browser's codecs).", "includeVideo");
		tg("Other attachments", "Word, ZIP … offered as download buttons.", "includeOther");
		new Setting(el).setName("Large file warning (MB)").addText((t) => t.setValue(String(o.largeFileMB)).onChange((v) => { const n = Number(v); if (n > 0) { o.largeFileMB = n; this.save(); } }));
		el.createEl("h3", { text: "Scan result" });
		const box = el.createDiv();
		void this.runScan(() => { box.empty(); this.summary(box); });
	}
	private stepPreview(el: HTMLElement): void {
		el.createEl("h2", { text: "Preview" });
		const box = el.createDiv();
		void this.runScan(() => { box.empty(); this.summary(box); });
		const actions = el.createDiv({ cls: "olwb-actions" });
		const b = actions.createEl("button", { text: "Open full preview in browser" });
		b.onclick = async () => {
			b.disabled = true; b.setText("Building preview…");
			try { await previewInBrowser(this.plugin, { courses: this.s.courses, design: this.s.design, options: this.s.options }); } catch (e) { new Notice((e as Error).message, 8000); }
			b.disabled = false; b.setText("Open full preview in browser");
		};
		const host = el.createDiv({ cls: "olwb-right olwb-wide-preview" });
		this.mountPreview(host)();
	}

	// ---------------------------------------------------------------- step 6 / 7
	private stepExport(el: HTMLElement): void {
		el.createEl("h2", { text: "Export" });
		const single = this.s.options.mode === "single";
		el.createEl("p", { text: single ? "Your note or course will be written as an HTML page." : "Your website will be written into the folder below. Existing files made by this plugin are updated; other files are never touched." });
		new ExportPanel(this.plugin, el, () => ({ courses: this.s.courses, design: this.s.design, options: this.s.options }), (o) => { this.outcome = o; this.step = 6; this.render(); });
	}
	private stepDone(el: HTMLElement): void {
		if (!this.outcome) { el.createEl("p", { text: "Nothing exported yet." }); return; }
		renderOutcome(el, this.outcome);
		el.createEl("h4", { text: "How to use it" });
		const ol = el.createEl("ol");
		const site = this.outcome.plan.options.mode === "site";
		for (const t of site
			? ["Open the output folder and double-click index.html.", "To share it, copy the whole folder (USB drive, zip, cloud). Keep the folders together.", "To refresh it after editing notes, run the command “Update Existing Website”."]
			: ["Double-click the HTML file to open it in your browser.", this.outcome.plan.options.embed ? "Everything is inside that one file; you can email or copy it." : "Keep the page next to its “_assets” folder when copying it.", "Press Ctrl/⌘+K inside the page to search."]) ol.createEl("li", { text: t });
		const row = el.createDiv({ cls: "olwb-actions" });
		row.createEl("button", { text: "Copy path" }).onclick = async () => { await copyText(this.outcome!.entryPath); new Notice("Path copied"); };
		row.createEl("button", { text: "Open output folder" }).onclick = () => void openPath(this.outcome!.outputDir);
	}
}
